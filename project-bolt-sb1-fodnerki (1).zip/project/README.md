# NDDC Tender Confirmation System

A comprehensive tender confirmation system with search functionality and admin portal for the Niger Delta Development Commission (NDDC).

## 🚀 Features

### Main Website
- **Simple Search Interface**: Clean, user-friendly search by tender ID
- **Popup Details**: Complete tender information in modal popup
- **Mobile Responsive**: Optimized for all devices
- **Real-time Search**: Instant results with loading states

### Admin Portal
- **Complete CRUD Operations**: Create, read, update, delete tenders
- **Dashboard Analytics**: Overview of tender statistics
- **User Authentication**: Secure login system
- **Document Management**: Handle multiple documents per tender
- **Audit Logging**: Track all system activities
- **Settings Management**: Configure system parameters

### Database
- **MySQL Database**: Complete schema with relationships
- **Stored Procedures**: Optimized database operations
- **Audit Trail**: Complete logging of all activities
- **Performance Indexes**: Optimized for fast searches
- **Sample Data**: Ready-to-use test data

## 📁 Project Structure

```
├── src/                          # Main website
│   ├── components/              # React components
│   ├── pages/                   # Page components
│   └── ...
├── admin/                       # Admin portal (separate app)
│   ├── src/
│   │   ├── components/         # Admin components
│   │   ├── pages/              # Admin pages
│   │   └── ...
├── api/                         # PHP API endpoints
│   ├── config/                 # Database configuration
│   ├── admin/                  # Admin API endpoints
│   └── search_tender.php       # Main search endpoint
├── database/                    # Database files
│   └── nddc_tenders.sql        # Complete database schema
└── ...
```

## 🛠️ Installation

### 1. Main Website Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### 2. Admin Portal Setup

```bash
# Start admin development server
npm run admin

# Build admin for production
npm run build
```

### 3. Database Setup

1. **Upload to phpMyAdmin**:
   - Open phpMyAdmin in your cPanel
   - Create a new database named `nddc_tenders`
   - Import the `database/nddc_tenders.sql` file

2. **Configure Database Connection**:
   - Edit `api/config/database.php`
   - Update database credentials:
   ```php
   private $host = "localhost";           // Your database host
   private $db_name = "nddc_tenders";     // Your database name
   private $username = "your_db_user";    // Your database username
   private $password = "your_db_password"; // Your database password
   ```

### 4. API Setup

1. Upload the `api/` folder to your web server
2. Ensure PHP 7.4+ is installed
3. Configure database connection in `api/config/database.php`

## 🔧 Configuration

### Environment Variables

Create `.env` files for both main site and admin:

**Main Site (.env)**:
```
VITE_API_BASE_URL=https://yourdomain.com/api
```

**Admin Portal (admin/.env)**:
```
VITE_API_BASE_URL=https://yourdomain.com/api/admin
```

### Database Configuration

Update `api/config/database.php` with your hosting details:

```php
private $host = "localhost";           // Usually localhost
private $db_name = "nddc_tenders";     // Your database name
private $username = "your_db_user";    // Database username
private $password = "your_db_password"; // Database password
```

## 🎯 Usage

### Main Website

1. **Search Tender**:
   - Enter tender ID (e.g., TND/2024/001)
   - Click search or press Enter
   - View details in popup modal

2. **Sample Tender IDs**:
   - `TND/2024/001` - Construction project
   - `TND/2024/002` - Medical equipment supply
   - `TND/2023/089` - Rural electrification

### Admin Portal

1. **Login**:
   - Username: `admin`
   - Password: `admin123`

2. **Manage Tenders**:
   - Create new tenders
   - Edit existing tenders
   - Delete tenders
   - View analytics

3. **Features**:
   - Dashboard with statistics
   - Complete tender management
   - Document handling
   - System settings

## 🗄️ Database Schema

### Main Tables

- **`tenders`**: Core tender information
- **`tender_documents`**: Document attachments
- **`admin_users`**: Admin user accounts
- **`audit_logs`**: System activity logs
- **`system_settings`**: Configuration settings

### Key Features

- **Stored Procedures**: `GetTenderById`, `SearchTenders`, `UpdateTenderStatus`
- **Views**: `tender_summary`, `monthly_tender_stats`
- **Triggers**: Automatic audit logging
- **Indexes**: Performance optimized

## 🔐 Security Features

- **SQL Injection Protection**: Prepared statements
- **XSS Prevention**: Input sanitization
- **CSRF Protection**: Token validation
- **Audit Logging**: Complete activity tracking
- **Password Hashing**: Secure password storage
- **Session Management**: Secure admin sessions

## 📱 Mobile Optimization

- **Responsive Design**: Works on all screen sizes
- **Touch-Friendly**: Optimized for mobile interaction
- **Fast Loading**: Optimized for mobile networks
- **Progressive Enhancement**: Works without JavaScript

## 🚀 Deployment

### Main Website

1. Build the project: `npm run build`
2. Upload `dist/` folder to your web server
3. Configure web server to serve the files

### Admin Portal

1. Build admin: `npm run build` (with admin config)
2. Upload `dist-admin/` folder to your web server
3. Access via `/admin` or separate subdomain

### API

1. Upload `api/` folder to your web server
2. Ensure PHP and MySQL are configured
3. Set proper file permissions
4. Test API endpoints

## 🔧 API Endpoints

### Public Endpoints

- `GET /api/search_tender.php?id={tender_id}` - Search tender by ID
- `POST /api/search_tender.php` - Search tender (JSON body)

### Admin Endpoints

- `POST /api/admin/auth.php` - Admin login
- `GET /api/admin/tenders.php` - Get all tenders
- `POST /api/admin/tenders.php` - Create tender
- `PUT /api/admin/tenders.php` - Update tender
- `DELETE /api/admin/tenders.php?id={id}` - Delete tender

## 🎨 Customization

### Styling

- Edit Tailwind CSS classes in components
- Modify `src/index.css` for global styles
- Update color scheme in Tailwind config

### Branding

- Replace logo in `public/NDDCNewLogo.jpg`
- Update site title in `index.html`
- Modify contact information in components

### Functionality

- Add new tender fields in database schema
- Update API endpoints for new fields
- Modify frontend forms and displays

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Failed**:
   - Check database credentials in `api/config/database.php`
   - Ensure database server is running
   - Verify database name exists

2. **API Not Working**:
   - Check PHP error logs
   - Verify file permissions
   - Ensure mod_rewrite is enabled

3. **Search Not Working**:
   - Check browser console for errors
   - Verify API endpoint URLs
   - Test API endpoints directly

### Debug Mode

Enable debug mode in admin settings to see detailed error messages.

## 📞 Support

For technical support or questions:

- **Email**: admin@nddcbpdivc.com.ng
- **Phone**: +2347013253195
- **Office Hours**: Mon - Fri: 8:00 AM - 5:00 PM

## 📄 License

This project is proprietary software developed for the Niger Delta Development Commission (NDDC).

## 🔄 Updates

### Version 1.0.0
- Initial release
- Basic search functionality
- Admin portal
- Database schema
- Mobile optimization

---

**Built with ❤️ for NDDC by the Development Team**