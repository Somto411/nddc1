<?php
/**
 * Admin Tender Management API
 * 
 * Handles CRUD operations for tenders in the admin panel
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once '../config/database.php';

// Check authentication (in production, implement proper JWT or session validation)
function checkAuth() {
    return isset($_SESSION['admin_id']);
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            // Get all tenders or specific tender
            if (isset($_GET['id'])) {
                // Get specific tender
                $tender_id = $_GET['id'];
                $query = "CALL GetTenderById(:tender_id)";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':tender_id', $tender_id);
                $stmt->execute();
                
                $tender = $stmt->fetch();
                if ($tender) {
                    $documents = [];
                    if (!empty($tender['documents'])) {
                        $documents = explode('|', $tender['documents']);
                    }
                    
                    echo json_encode([
                        'success' => true,
                        'data' => array_merge($tender, ['documents' => $documents])
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'Tender not found']);
                }
            } else {
                // Get all tenders with pagination
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
                $search = isset($_GET['search']) ? $_GET['search'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : 'all';
                
                $offset = ($page - 1) * $limit;
                
                $query = "CALL SearchTenders(:search, :status, :limit, :offset)";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':search', $search);
                $stmt->bindParam(':status', $status);
                $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
                $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
                $stmt->execute();
                
                $tenders = $stmt->fetchAll();
                
                // Get total count
                $count_query = "SELECT COUNT(*) as total FROM tender_summary WHERE 1=1";
                if (!empty($search)) {
                    $count_query .= " AND (title LIKE :search OR company LIKE :search OR id LIKE :search)";
                }
                if ($status !== 'all') {
                    $count_query .= " AND status = :status";
                }
                
                $count_stmt = $db->prepare($count_query);
                if (!empty($search)) {
                    $search_param = "%$search%";
                    $count_stmt->bindParam(':search', $search_param);
                }
                if ($status !== 'all') {
                    $count_stmt->bindParam(':status', $status);
                }
                $count_stmt->execute();
                $total = $count_stmt->fetch()['total'];
                
                echo json_encode([
                    'success' => true,
                    'data' => $tenders,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'pages' => ceil($total / $limit)
                    ]
                ]);
            }
            break;
            
        case 'POST':
            // Create new tender
            if (!checkAuth()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            $query = "INSERT INTO tenders (id, title, company, amount, status, submission_date, opening_date, 
                      description, contact_person, email, phone, evaluation_status, validity_period) 
                      VALUES (:id, :title, :company, :amount, :status, :submission_date, :opening_date, 
                      :description, :contact_person, :email, :phone, :evaluation_status, :validity_period)";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $input['id']);
            $stmt->bindParam(':title', $input['title']);
            $stmt->bindParam(':company', $input['company']);
            $stmt->bindParam(':amount', $input['amount']);
            $stmt->bindParam(':status', $input['status']);
            $stmt->bindParam(':submission_date', $input['submissionDate']);
            $stmt->bindParam(':opening_date', $input['openingDate']);
            $stmt->bindParam(':description', $input['description']);
            $stmt->bindParam(':contact_person', $input['contactPerson']);
            $stmt->bindParam(':email', $input['email']);
            $stmt->bindParam(':phone', $input['phone']);
            $stmt->bindParam(':evaluation_status', $input['evaluationStatus']);
            $stmt->bindParam(':validity_period', $input['validityPeriod']);
            
            if ($stmt->execute()) {
                // Insert documents
                if (!empty($input['documents'])) {
                    $doc_query = "INSERT INTO tender_documents (tender_id, document_name) VALUES (:tender_id, :document_name)";
                    $doc_stmt = $db->prepare($doc_query);
                    
                    foreach ($input['documents'] as $document) {
                        if (!empty($document)) {
                            $doc_stmt->bindParam(':tender_id', $input['id']);
                            $doc_stmt->bindParam(':document_name', $document);
                            $doc_stmt->execute();
                        }
                    }
                }
                
                echo json_encode(['success' => true, 'message' => 'Tender created successfully']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to create tender']);
            }
            break;
            
        case 'PUT':
            // Update tender
            if (!checkAuth()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            $query = "UPDATE tenders SET title = :title, company = :company, amount = :amount, 
                      status = :status, submission_date = :submission_date, opening_date = :opening_date,
                      description = :description, contact_person = :contact_person, email = :email,
                      phone = :phone, evaluation_status = :evaluation_status, validity_period = :validity_period
                      WHERE id = :id";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $input['id']);
            $stmt->bindParam(':title', $input['title']);
            $stmt->bindParam(':company', $input['company']);
            $stmt->bindParam(':amount', $input['amount']);
            $stmt->bindParam(':status', $input['status']);
            $stmt->bindParam(':submission_date', $input['submissionDate']);
            $stmt->bindParam(':opening_date', $input['openingDate']);
            $stmt->bindParam(':description', $input['description']);
            $stmt->bindParam(':contact_person', $input['contactPerson']);
            $stmt->bindParam(':email', $input['email']);
            $stmt->bindParam(':phone', $input['phone']);
            $stmt->bindParam(':evaluation_status', $input['evaluationStatus']);
            $stmt->bindParam(':validity_period', $input['validityPeriod']);
            
            if ($stmt->execute()) {
                // Update documents
                $del_query = "DELETE FROM tender_documents WHERE tender_id = :tender_id";
                $del_stmt = $db->prepare($del_query);
                $del_stmt->bindParam(':tender_id', $input['id']);
                $del_stmt->execute();
                
                if (!empty($input['documents'])) {
                    $doc_query = "INSERT INTO tender_documents (tender_id, document_name) VALUES (:tender_id, :document_name)";
                    $doc_stmt = $db->prepare($doc_query);
                    
                    foreach ($input['documents'] as $document) {
                        if (!empty($document)) {
                            $doc_stmt->bindParam(':tender_id', $input['id']);
                            $doc_stmt->bindParam(':document_name', $document);
                            $doc_stmt->execute();
                        }
                    }
                }
                
                echo json_encode(['success' => true, 'message' => 'Tender updated successfully']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to update tender']);
            }
            break;
            
        case 'DELETE':
            // Delete tender
            if (!checkAuth()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                break;
            }
            
            $tender_id = $_GET['id'] ?? '';
            
            if (empty($tender_id)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tender ID is required']);
                break;
            }
            
            $query = "DELETE FROM tenders WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $tender_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Tender deleted successfully']);
            } else {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to delete tender']);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
            break;
    }
    
} catch (Exception $e) {
    error_log("Tender API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error'
    ]);
}
?>