<?php
/**
 * NDDC Tender Search API Endpoint
 * 
 * This endpoint handles tender search requests from the frontend.
 * It searches for tenders by ID and returns complete tender information.
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

require_once 'config/database.php';

try {
    // Get the tender ID from request
    $tender_id = '';
    
    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
        $tender_id = trim($_GET['id']);
    } elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $tender_id = isset($input['id']) ? trim($input['id']) : '';
    }
    
    // Validate input
    if (empty($tender_id)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Tender ID is required'
        ]);
        exit;
    }
    
    // Connect to database
    $database = new Database();
    $db = $database->getConnection();
    
    // Search for tender
    $query = "CALL GetTenderById(:tender_id)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':tender_id', $tender_id, PDO::PARAM_STR);
    $stmt->execute();
    
    $tender = $stmt->fetch();
    
    if ($tender) {
        // Process documents
        $documents = [];
        if (!empty($tender['documents'])) {
            $documents = explode('|', $tender['documents']);
        }
        
        // Format response
        $response = [
            'success' => true,
            'data' => [
                'id' => $tender['id'],
                'title' => $tender['title'],
                'company' => $tender['company'],
                'amount' => $tender['amount'],
                'status' => $tender['status'],
                'submissionDate' => $tender['submission_date'],
                'openingDate' => $tender['opening_date'],
                'description' => $tender['description'],
                'contactPerson' => $tender['contact_person'],
                'email' => $tender['email'],
                'phone' => $tender['phone'],
                'evaluationStatus' => $tender['evaluation_status'],
                'validityPeriod' => $tender['validity_period'],
                'documents' => $documents
            ]
        ];
        
        // Log the search (optional)
        $log_query = "INSERT INTO audit_logs (action, table_name, record_id, ip_address, user_agent) 
                      VALUES ('SEARCH', 'tenders', :tender_id, :ip, :user_agent)";
        $log_stmt = $db->prepare($log_query);
        $log_stmt->bindParam(':tender_id', $tender_id);
        $log_stmt->bindParam(':ip', $_SERVER['REMOTE_ADDR']);
        $log_stmt->bindParam(':user_agent', $_SERVER['HTTP_USER_AGENT']);
        $log_stmt->execute();
        
        echo json_encode($response);
    } else {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Tender not found'
        ]);
    }
    
} catch (Exception $e) {
    error_log("Tender search error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error'
    ]);
}
?>