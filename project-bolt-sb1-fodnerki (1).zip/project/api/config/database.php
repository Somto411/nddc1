<?php
/**
 * Database Configuration for NDDC Tender Confirmation System
 * 
 * This file contains database connection settings.
 * Update these values according to your hosting environment.
 */

class Database {
    // Database credentials - UPDATE THESE VALUES
    private $host = "localhost";           // Your database host
    private $db_name = "nddc_tenders";     // Your database name
    private $username = "your_db_user";    // Your database username
    private $password = "your_db_password"; // Your database password
    private $charset = "utf8mb4";
    
    public $conn;
    
    /**
     * Get database connection
     */
    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch(PDOException $exception) {
            error_log("Connection error: " . $exception->getMessage());
            throw new Exception("Database connection failed");
        }
        
        return $this->conn;
    }
}
?>