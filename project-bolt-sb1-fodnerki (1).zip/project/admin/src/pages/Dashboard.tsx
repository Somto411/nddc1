import React from 'react';
import { FileText, CheckCircle, Clock, AlertCircle, TrendingUp, Users, DollarSign } from 'lucide-react';

const Dashboard = () => {
  const stats = [
    {
      title: 'Total Tenders',
      value: '156',
      change: '+12%',
      changeType: 'increase',
      icon: FileText,
      color: 'bg-blue-500'
    },
    {
      title: 'Active Submissions',
      value: '43',
      change: '+8%',
      changeType: 'increase',
      icon: Clock,
      color: 'bg-orange-500'
    },
    {
      title: 'Completed',
      value: '89',
      change: '+15%',
      changeType: 'increase',
      icon: CheckCircle,
      color: 'bg-green-500'
    },
    {
      title: 'Total Value',
      value: '₦2.5T',
      change: '+22%',
      changeType: 'increase',
      icon: DollarSign,
      color: 'bg-purple-500'
    }
  ];

  const recentTenders = [
    {
      id: 'TND/2024/001',
      title: 'Construction of Calabar-Itu Highway',
      company: 'ABC Construction Ltd',
      amount: '₦95,000,000,000',
      status: 'Under Review',
      date: '2024-01-15'
    },
    {
      id: 'TND/2024/002',
      title: 'Supply of Medical Equipment',
      company: 'MedEquip Nigeria Ltd',
      amount: '₦15,000,000,000',
      status: 'Shortlisted',
      date: '2024-01-20'
    },
    {
      id: 'TND/2023/089',
      title: 'Rural Electrification Project',
      company: 'PowerGrid Solutions',
      amount: '₦28,000,000,000',
      status: 'Contract Awarded',
      date: '2023-11-10'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Under Review':
        return 'bg-blue-100 text-blue-800';
      case 'Shortlisted':
        return 'bg-orange-100 text-orange-800';
      case 'Contract Awarded':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="text-sm text-gray-500">
          Last updated: {new Date().toLocaleString()}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                <p className={`text-sm ${stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.change} from last month
                </p>
              </div>
              <div className={`${stat.color} p-3 rounded-full`}>
                <stat.icon className="text-white" size={24} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Tenders */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Recent Tender Submissions</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentTenders.map((tender) => (
                <div key={tender.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{tender.title}</h3>
                    <p className="text-sm text-gray-600">{tender.company}</p>
                    <p className="text-sm font-medium text-green-600">{tender.amount}</p>
                  </div>
                  <div className="text-right">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(tender.status)}`}>
                      {tender.status}
                    </span>
                    <p className="text-xs text-gray-500 mt-1">{tender.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <button className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center">
                <FileText className="mr-2" size={20} />
                Create New Tender
              </button>
              <button className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                <CheckCircle className="mr-2" size={20} />
                Review Submissions
              </button>
              <button className="w-full bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center">
                <TrendingUp className="mr-2" size={20} />
                Generate Report
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">System Status</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
            <span className="text-sm text-gray-600">Database: Online</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
            <span className="text-sm text-gray-600">API: Operational</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
            <span className="text-sm text-gray-600">Search: Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;