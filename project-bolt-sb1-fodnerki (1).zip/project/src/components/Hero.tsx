import React from 'react';
import { ArrowRight, FileText, Users, Trophy } from 'lucide-react';

const Hero = () => {
  return (
    <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Niger Delta Development Commission
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Transparent Procurement and Bidding Portal for Sustainable Development
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
            <button className="bg-white text-green-800 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center justify-center">
              View Current Tenders
              <ArrowRight className="ml-2" size={20} />
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-green-800 transition-colors">
              Learn More
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="text-center p-6 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <FileText className="mx-auto mb-4 text-green-200" size={48} />
            <h3 className="text-xl font-semibold mb-2">Transparent Bidding</h3>
            <p className="text-green-100">
              Open and fair procurement process for all qualified contractors
            </p>
          </div>
          <div className="text-center p-6 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <Users className="mx-auto mb-4 text-green-200" size={48} />
            <h3 className="text-xl font-semibold mb-2">Community Focus</h3>
            <p className="text-green-100">
              Development projects that benefit Niger Delta communities
            </p>
          </div>
          <div className="text-center p-6 bg-white bg-opacity-10 rounded-lg backdrop-blur-sm">
            <Trophy className="mx-auto mb-4 text-green-200" size={48} />
            <h3 className="text-xl font-semibold mb-2">Excellence</h3>
            <p className="text-green-100">
              Commitment to quality and timely project delivery
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;