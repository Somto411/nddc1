import React from 'react';
import { CheckCircle } from 'lucide-react';

const CoreFocusSection = () => {
  const focusAreas = [
    "Enhancing Infrastructure in the Niger Delta.",
    "Improving Healthcare Access for our People.",
    "Empowering Communities through Education, Skills and Jobs.",
    "Sustainable Environmental Management of our Environment and Resources.",
    "Facilitating Agricultural Development and supporting Agro Allied Industries.",
    "Fostering Social Welfare Programs for all our people."
  ];

  return (
    <section 
      className="py-20 relative"
      style={{
        backgroundImage: "linear-gradient(rgba(3, 51, 92, 0.8), rgba(3, 51, 92, 0.8)), url('https://images.pexels.com/photos/1117452/pexels-photo-1117452.jpeg?auto=compress&cs=tinysrgb&w=1600')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-8">
            Core Focus of the Niger Delta Development Commission
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Focus Areas */}
          <div>
            <ul className="space-y-4">
              {focusAreas.map((area, index) => (
                <li key={index} className="flex items-start text-white">
                  <CheckCircle className="text-green-400 mr-3 mt-1 flex-shrink-0" size={20} />
                  <span className="text-lg font-medium">{area}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Vision, Mission, Values */}
          <div className="space-y-6">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-6">
              <h4 className="text-xl font-semibold text-white mb-3 flex items-center">
                <CheckCircle className="text-green-400 mr-2" size={20} />
                Vision
              </h4>
              <p className="text-white">
                To offer a lasting solution to the socio-economic difficulties in the Niger Delta region.
              </p>
            </div>

            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-6">
              <h4 className="text-xl font-semibold text-white mb-3 flex items-center">
                <CheckCircle className="text-green-400 mr-2" size={20} />
                Mission
              </h4>
              <p className="text-white">
                To facilitate the rapid and sustainable development of the Niger Delta into a region that is economically
                prosperous, socially stable, ecologically regenerative and politically peaceful.
              </p>
            </div>

            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-6">
              <h4 className="text-xl font-semibold text-white mb-3 flex items-center">
                <CheckCircle className="text-green-400 mr-2" size={20} />
                Core Values
              </h4>
              <p className="text-white">
                Patriotism, Passion, Professionalism, Integrity, Creativity and Team Spirit
              </p>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <a
            href="/our-mission"
            className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
          >
            Discover More
          </a>
        </div>
      </div>
    </section>
  );
};

export default CoreFocusSection;