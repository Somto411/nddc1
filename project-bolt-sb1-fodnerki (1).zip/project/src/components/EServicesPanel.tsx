import React from 'react';
import { Link } from 'react-router-dom';
import { Database, CheckCircle, GraduationCap, X } from 'lucide-react';

interface EServicesPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const EServicesPanel = ({ isOpen, onClose }: EServicesPanelProps) => {
  const services = [
    {
      name: 'Project Database',
      icon: Database,
      description: 'Access comprehensive project information',
      href: '/project-database',
    },
    {
      name: 'Tender Confirmation',
      icon: CheckCircle,
      description: 'Confirm tender submissions and status',
      href: '/tender-confirmation',
    },
    {
      name: 'Scholarships',
      icon: GraduationCap,
      description: 'Apply for educational scholarships',
      href: '/scholarships',
    },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      {/* Panel */}
      <div className="absolute right-0 top-0 h-full w-full sm:w-80 bg-white shadow-xl">
        <div className="p-4 sm:p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg sm:text-xl font-bold text-green-800">E-Services</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 p-2"
            >
              <X size={24} />
            </button>
          </div>

          <div className="space-y-4">
            {services.map((service) => (
              <Link
                key={service.name}
                to={service.href}
                onClick={onClose}
                className="block p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
              >
                <div className="flex items-start space-x-3">
                  <service.icon className="text-green-600 mt-1 flex-shrink-0" size={20} />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-green-800 text-sm sm:text-base">{service.name}</h3>
                    <p className="text-xs sm:text-sm text-gray-600 mt-1">{service.description}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EServicesPanel;