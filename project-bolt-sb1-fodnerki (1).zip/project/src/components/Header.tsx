import React, { useState } from 'react';
import { Menu, X, ChevronDown, Settings } from 'lucide-react';
import Navigation from './Navigation';
import EServicesPanel from './EServicesPanel';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isEServicesOpen, setIsEServicesOpen] = useState(false);

  return (
    <header className="relative">
      {/* Top Bar */}
      <div className="bg-green-800 text-white py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center text-xs sm:text-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 mb-2 sm:mb-0">
            <span className="font-semibold">Welcome to NDDC Bids and Procurement Portal</span>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-1 sm:space-y-0 sm:space-x-4 text-xs">
            <span className="hidden sm:inline">Contact: +2347013253195</span>
            <span className="hidden md:inline">Email: info@nddcbpdivc.com.ng</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 sm:h-20">
            {/* Logo */}
            <div className="flex items-center flex-shrink-0">
              <div className="flex items-center">
                <img 
                  src="/NDDCNewLogo.jpg" 
                  alt="NDDC Logo" 
                  className="h-10 sm:h-12 md:h-16 w-auto"
                />
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:block">
              <Navigation />
            </div>

            {/* Mobile Menu Button & E-Services */}
            <div className="flex items-center space-x-2 sm:space-x-4">
              <button
                onClick={() => setIsEServicesOpen(!isEServicesOpen)}
                className="bg-green-600 text-white px-2 sm:px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center space-x-1 sm:space-x-2 text-xs sm:text-sm"
              >
                <Settings size={16} className="sm:w-5 sm:h-5" />
                <span className="hidden sm:inline">E-Services</span>
                <span className="sm:hidden">E-Svc</span>
                <ChevronDown size={12} className={`transition-transform ${isEServicesOpen ? 'rotate-180' : ''} sm:w-4 sm:h-4`} />
              </button>

              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden text-gray-600 hover:text-green-600 p-2"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden border-t bg-white">
            <Navigation mobile={true} />
          </div>
        )}
      </div>

      {/* E-Services Panel */}
      <EServicesPanel isOpen={isEServicesOpen} onClose={() => setIsEServicesOpen(false)} />
    </header>
  );
};

export default Header;