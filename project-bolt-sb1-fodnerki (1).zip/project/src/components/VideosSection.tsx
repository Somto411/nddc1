import React from 'react';

const VideosSection = () => {
  const videos = [
    {
      id: "OPu25OiCkzU",
      title: "NDDC Inaugurates Aquaculture Training Centre"
    },
    {
      id: "7FNJEvM3Mtg",
      title: "Community Development Projects"
    },
    {
      id: "6plvkizQOv4",
      title: "Infrastructure Development Updates"
    }
  ];

  const mainVideo = {
    id: "MrYIVI_JKP4",
    title: "NDDC Main Feature Video"
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="text-green-600 font-medium mb-2">Videos of Activities from the Region</div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Videos</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Side Videos */}
          <div className="space-y-4">
            {videos.map((video, index) => (
              <div key={index} className="aspect-video">
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${video.id}?rel=0&cc_load_policy=1&color=white`}
                  title={video.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  className="rounded-lg"
                ></iframe>
              </div>
            ))}
          </div>

          {/* Main Video */}
          <div className="lg:col-span-3">
            <div className="aspect-video">
              <iframe
                width="100%"
                height="100%"
                src={`https://www.youtube.com/embed/${mainVideo.id}?rel=0&cc_load_policy=1&color=white`}
                title={mainVideo.title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                className="rounded-lg"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VideosSection;