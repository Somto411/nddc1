import React from 'react';
import { FileText, Info } from 'lucide-react';

const ReportCenterSection = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center">
                <FileText className="text-green-600" size={32} />
              </div>
              <div>
                <h4 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  NDDC
                  <div className="bg-green-600 text-white w-8 h-8 rounded-full flex items-center justify-center">
                    <Info size={16} />
                  </div>
                  Report Center
                </h4>
                <p className="text-gray-600 mt-2 max-w-2xl">
                  You can send us a report on the performance of NDDC Projects in your community to give us 
                  direct performance reports on our project.
                </p>
              </div>
            </div>
            <div className="flex-shrink-0">
              <a
                href="/project-database"
                className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors inline-flex items-center gap-2"
              >
                Send
                <div className="bg-green-800 text-white w-6 h-6 rounded-full flex items-center justify-center">
                  <Info size={12} />
                </div>
                Report
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ReportCenterSection;