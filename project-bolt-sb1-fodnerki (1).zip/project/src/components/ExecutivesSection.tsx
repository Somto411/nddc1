import React from 'react';

const ExecutivesSection = () => {
  const executives = [
    {
      name: "Mr. Chiedu Ebie",
      position: "Chairman",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-Chair.png"
    },
    {
      name: "Dr. Samuel Ogbuku",
      position: "MD",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-MD.png"
    },
    {
      name: "Mr. Victor Antai",
      position: "EDP",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-EDP.png"
    },
    {
      name: "Mr. Ifedayo Abegunde",
      position: "EDCS",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-EDCS.png"
    },
    {
      name: "Mr. Boma Iyaye",
      position: "EDFA",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-EDFA.png"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
          <div>
            <div className="text-green-600 font-medium mb-2">Our People</div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Our Executives And Management Staff
            </h2>
          </div>
          <div>
            <p className="text-lg text-gray-700">
              The Niger Delta Development Commission is Governed by seasoned experts from across the region 
              that help navigate the affairs of the Commission.
            </p>
          </div>
        </div>

        {/* Chairman - Featured */}
        <div className="mb-12">
          <div className="bg-gray-50 rounded-lg p-8 text-center max-w-md mx-auto">
            <img
              src={executives[0].image}
              alt={executives[0].name}
              className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
            />
            <h4 className="text-xl font-semibold text-gray-900 mb-2">
              <a href="/our-board" className="hover:text-green-600 transition-colors">
                {executives[0].name}
              </a>
            </h4>
            <p className="text-green-600 font-medium">{executives[0].position}</p>
          </div>
        </div>

        {/* Other Executives */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          {executives.slice(1).map((executive, index) => (
            <div key={index} className="text-center">
              <img
                src={executive.image}
                alt={executive.name}
                className="w-24 h-24 rounded-full mx-auto mb-3 object-cover"
              />
              <h4 className="font-semibold text-gray-900 mb-1">
                <a href="/our-board" className="hover:text-green-600 transition-colors">
                  {executive.name}
                </a>
              </h4>
              <p className="text-green-600 text-sm">{executive.position}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <a
            href="/our-board"
            className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
          >
            View More
          </a>
        </div>
      </div>
    </section>
  );
};

export default ExecutivesSection;