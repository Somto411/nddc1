import React from 'react';
import { Link } from 'react-router-dom';
import { Target, Users, Building, FileText, Award, Heart } from 'lucide-react';

const DepartmentCards = () => {
  const departments = [
    {
      icon: Target,
      title: "Our Mission",
      href: "/our-mission"
    },
    {
      icon: Users,
      title: "Our Leadership",
      href: "/our-board"
    },
    {
      icon: Building,
      title: "Projects & Programs",
      href: "/projects"
    },
    {
      icon: FileText,
      title: "Online Forms",
      href: "/supply-procedure"
    },
    {
      icon: Award,
      title: "Tenders & Adverts",
      href: "/supply-requirements"
    },
    {
      icon: Heart,
      title: "Empowerment Programs",
      href: "/scholarships"
    }
  ];

  return (
    <section className="py-12 sm:py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6 mb-8 sm:mb-12">
          {departments.map((dept, index) => (
            <Link
              key={index}
              to={dept.href}
              className="group bg-white p-4 sm:p-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 text-center"
            >
              <div className="bg-green-100 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 group-hover:bg-green-600 transition-colors">
                <dept.icon className="text-green-600 group-hover:text-white transition-colors" size={24} />
              </div>
              <h5 className="font-semibold text-gray-900 group-hover:text-green-600 transition-colors text-xs sm:text-sm lg:text-base">
                {dept.title}
              </h5>
            </Link>
          ))}
        </div>

        {/* Newsletter Subscription */}
        <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
          <form className="flex flex-col sm:flex-row gap-3 sm:gap-4 items-stretch sm:items-center justify-center">
            <input
              type="email"
              placeholder="Keep up with our Latest News and Updates"
              className="flex-1 max-w-md px-3 sm:px-4 py-2 sm:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm sm:text-base"
            />
            <button
              type="submit"
              className="bg-green-600 text-white px-6 sm:px-8 py-2 sm:py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors text-sm sm:text-base"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default DepartmentCards;