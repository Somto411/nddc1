import React from 'react';
import { Play, ArrowRight } from 'lucide-react';

const AboutSection = () => {
  return (
    <section className="py-12 sm:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          {/* Images */}
          <div className="relative order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              <div className="space-y-3 sm:space-y-4">
                <div className="relative overflow-hidden rounded-lg">
                  <img
                    src="https://images.pexels.com/photos/1117452/pexels-photo-1117452.jpeg?auto=compress&cs=tinysrgb&w=600"
                    alt="NDDC Projects"
                    className="w-full h-48 sm:h-64 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                    <button className="bg-green-600 text-white w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center hover:bg-green-700 transition-colors">
                      <Play size={20} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="space-y-3 sm:space-y-4 mt-6 sm:mt-8">
                <img
                  src="https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Niger Delta Development"
                  className="w-full h-36 sm:h-48 object-cover rounded-lg"
                />
                <img
                  src="https://images.pexels.com/photos/159306/construction-site-build-construction-work-159306.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Infrastructure Development"
                  className="w-full h-24 sm:h-32 object-cover rounded-lg"
                />
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="order-1 lg:order-2">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4 sm:mb-6">
              Welcome to Niger Delta Development Commission
            </h2>
            <p className="text-base sm:text-lg text-gray-700 leading-relaxed mb-6 sm:mb-8">
              Explore our website to unveil our steadfast dedication to fostering sustainable development, 
              empowering communities, and catalyzing positive transformation across the Niger Delta region. 
              From bolstering infrastructure to advancing social welfare initiatives, we are steadfastly 
              committed to creating opportunities and enhancing livelihoods. We invite you to embark on 
              this journey with us towards a future brimming with prosperity and progress.
            </p>
            <a
              href="/our-mission"
              className="inline-flex items-center text-green-600 hover:text-green-700 font-semibold text-base sm:text-lg"
            >
              LEARN MORE
              <ArrowRight className="ml-2" size={20} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;