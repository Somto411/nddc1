import React from 'react';
import { Calendar, ArrowRight } from 'lucide-react';

const LatestNews = () => {
  const news = [
    {
      title: 'New Infrastructure Development Tender Opens',
      date: 'December 15, 2024',
      excerpt: 'NDDC announces major infrastructure development project worth ₦5 billion for road construction across Niger Delta region.',
      href: '#',
    },
    {
      title: 'Scholarship Program Application Deadline Extended',
      date: 'December 10, 2024',
      excerpt: 'Application deadline for the 2024 NDDC Scholarship Program has been extended to January 31, 2025.',
      href: '#',
    },
    {
      title: 'Successful Completion of Rural Electrification Project',
      date: 'December 5, 2024',
      excerpt: 'NDDC successfully completes electrification project bringing power to 50 rural communities in Delta State.',
      href: '#',
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Latest News & Updates</h2>
            <p className="text-gray-600">Stay informed about our latest developments and opportunities</p>
          </div>
          <a
            href="#"
            className="hidden sm:flex items-center text-green-600 hover:text-green-700 font-semibold"
          >
            View All News
            <ArrowRight className="ml-2" size={20} />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {news.map((item) => (
            <article key={item.title} className="bg-gray-50 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex items-center text-gray-500 text-sm mb-3">
                  <Calendar size={16} className="mr-2" />
                  {item.date}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3 hover:text-green-600 cursor-pointer">
                  {item.title}
                </h3>
                <p className="text-gray-600 mb-4">{item.excerpt}</p>
                <a
                  href={item.href}
                  className="inline-flex items-center text-green-600 hover:text-green-700 font-semibold"
                >
                  Read More
                  <ArrowRight className="ml-2" size={16} />
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center mt-8 sm:hidden">
          <a
            href="#"
            className="inline-flex items-center text-green-600 hover:text-green-700 font-semibold"
          >
            View All News
            <ArrowRight className="ml-2" size={20} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default LatestNews;