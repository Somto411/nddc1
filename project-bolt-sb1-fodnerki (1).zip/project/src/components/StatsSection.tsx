import React from 'react';

const StatsSection = () => {
  const stats = [
    {
      number: "16k+",
      label: "Projects Delivered",
      description: "Since 2015 in All Regions.",
      icon: "🏃‍♂️"
    },
    {
      number: "60%",
      label: "Capital Projects",
      description: "Covering Roads, Electricity and Water Supply.",
      icon: "🏗️"
    },
    {
      number: "26%",
      label: "Private & Domestic",
      description: "Garden Land",
      icon: "🌱"
    },
    {
      number: "3000+",
      label: "Rural Projects",
      description: "Including Rural Electrification and Water Projects",
      icon: "🏘️"
    }
  ];

  return (
    <section className="py-16 bg-green-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center text-white">
              <div className="bg-white bg-opacity-20 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                {stat.icon}
              </div>
              <div className="mb-2">
                <h3 className="text-4xl font-bold">{stat.number}</h3>
              </div>
              <p className="text-xl font-semibold mb-2">{stat.label}</p>
              <p className="text-green-100 text-sm">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;