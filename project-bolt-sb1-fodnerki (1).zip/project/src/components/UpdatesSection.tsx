import React from 'react';
import { ArrowRight } from 'lucide-react';

const UpdatesSection = () => {
  const updates = [
    {
      id: 1,
      title: "Physical Infrastructure",
      description: "Physical Infrastructure Project development across the Niger Delta region...",
      image: "https://images.pexels.com/photos/1117452/pexels-photo-1117452.jpeg?auto=compress&cs=tinysrgb&w=600",
      icon: "🏗️",
      link: "/projects"
    },
    {
      id: 2,
      title: "Social Infrastructure",
      description: "Social Infrastructure Project initiatives for community development...",
      image: "https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=600",
      icon: "🏥",
      link: "/projects"
    },
    {
      id: 3,
      title: "Global Partnerships",
      description: "Global Partnership Project collaborations for sustainable growth...",
      image: "https://images.pexels.com/photos/159306/construction-site-build-construction-work-159306.jpeg?auto=compress&cs=tinysrgb&w=600",
      icon: "🤝",
      link: "/projects"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="text-green-600 font-medium mb-2">Updates From Our Programs and Activities</div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Updates</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {updates.map((update) => (
            <div key={update.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src={update.image}
                  alt={update.title}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute top-4 right-4 bg-green-600 text-white w-12 h-12 rounded-full flex items-center justify-center text-xl">
                  {update.icon}
                </div>
              </div>
              <div className="p-6">
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  <a href={update.link} className="hover:text-green-600 transition-colors">
                    {update.title}
                  </a>
                </h4>
                <p className="text-gray-600 mb-4 line-clamp-3">{update.description}</p>
                <a
                  href={update.link}
                  className="inline-flex items-center text-green-600 hover:text-green-700 font-semibold"
                >
                  <ArrowRight className="mr-2" size={16} />
                  Read More
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default UpdatesSection;