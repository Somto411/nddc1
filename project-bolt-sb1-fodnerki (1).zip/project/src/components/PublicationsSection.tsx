import React from 'react';
import { Download } from 'lucide-react';

const PublicationsSection = () => {
  const publications = [
    {
      title: "Building Partnerships for Regional Development",
      type: "News Letter",
      downloadUrl: "#"
    },
    {
      title: "A New Dawn Is Here",
      type: "News Letter",
      downloadUrl: "#"
    },
    {
      title: "New Thinking. New Frontiers. New Partnerships",
      type: "News Letter",
      downloadUrl: "#"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="text-green-600 font-medium mb-2">Our Recent Publications</div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Publications</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {publications.map((publication, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="h-52 flex flex-col justify-between">
                <div>
                  <h4 className="text-xl font-semibold text-gray-900 mb-3 line-clamp-3">
                    {publication.title}
                  </h4>
                  <p className="text-gray-600 mb-6">{publication.type}</p>
                </div>
                <a
                  href={publication.downloadUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-green-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                >
                  <Download className="mr-2" size={16} />
                  Download Now
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PublicationsSection;