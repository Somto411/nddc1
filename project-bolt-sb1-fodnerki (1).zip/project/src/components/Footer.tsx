import React from 'react';
import { Phone, Mail, MapPin, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {/* Logo and Description */}
          <div className="col-span-1 sm:col-span-2 lg:col-span-2">
            <div className="flex items-center mb-4">
              <img 
                src="/NDDCNewLogo.jpg" 
                alt="NDDC Logo" 
                className="h-10 sm:h-12 w-auto mr-3"
              />
            </div>
            <p className="text-gray-400 mb-4 sm:mb-6 max-w-md text-sm sm:text-base">
              Niger Delta Development Commission is committed to transparent procurement 
              and sustainable development of the Niger Delta region through effective project implementation.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-base sm:text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm sm:text-base">Current Tenders</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm sm:text-base">Our Mission</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm sm:text-base">Projects</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm sm:text-base">News</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors text-sm sm:text-base">Supply Requirements</a></li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="text-base sm:text-lg font-semibold mb-4">Contact Us</h4>
            <div className="space-y-3">
              <div className="flex items-start">
                <MapPin size={16} className="mr-3 text-green-400 mt-1 flex-shrink-0" />
                <span className="text-gray-400 text-xs sm:text-sm">
                  Plot 123, Constitution Avenue<br />
                  Central Business District<br />
                  Abuja, Nigeria
                </span>
              </div>
              <div className="flex items-center">
                <Phone size={16} className="mr-3 text-green-400 flex-shrink-0" />
                <span className="text-gray-400 text-xs sm:text-sm">+2347013253195</span>
              </div>
              <div className="flex items-center">
                <Mail size={16} className="mr-3 text-green-400 flex-shrink-0" />
                <span className="text-gray-400 text-xs sm:text-sm break-all">info@nddcbpdivc.com.ng</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-6 sm:mt-8 pt-6 sm:pt-8 text-center">
          <p className="text-gray-400 text-xs sm:text-sm">
            © 2024 Niger Delta Development Commission. All rights reserved. | Privacy Policy | Terms of Service
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;