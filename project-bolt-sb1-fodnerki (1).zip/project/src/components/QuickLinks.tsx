import React from 'react';
import { FileText, Download, Calendar, AlertCircle } from 'lucide-react';

const QuickLinks = () => {
  const quickLinks = [
    {
      title: 'Current Tenders',
      description: 'View all active tender opportunities',
      icon: FileText,
      href: '#',
      color: 'bg-green-600',
    },
    {
      title: 'Tender Documents',
      description: 'Download tender documents and specifications',
      icon: Download,
      href: '#',
      color: 'bg-blue-600',
    },
    {
      title: 'Submission Deadlines',
      description: 'Important dates and deadlines',
      icon: Calendar,
      href: '#',
      color: 'bg-orange-600',
    },
    {
      title: 'Notices & Updates',
      description: 'Latest announcements and updates',
      icon: AlertCircle,
      href: '#',
      color: 'bg-red-600',
    },
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Quick Access</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Access the most important procurement information and services
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {quickLinks.map((link) => (
            <a
              key={link.title}
              href={link.href}
              className="group bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <div className={`${link.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <link.icon className="text-white" size={24} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{link.title}</h3>
              <p className="text-gray-600 text-sm">{link.description}</p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default QuickLinks;