import React, { useEffect, useState } from 'react';
import { ArrowRight } from 'lucide-react';

const HeroSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      image: "https://images.pexels.com/photos/1117452/pexels-photo-1117452.jpeg?auto=compress&cs=tinysrgb&w=1600",
      title: "NDDC to Support 4,500 Rice, Cassava Farmers to Boost Food Security",
      subtitle: "Niger Delta Development Commission",
      link: "/news"
    },
    {
      id: 2,
      image: "https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=1600",
      title: "PRESS STATEMENT NDDC 2024 Budget: Need to Fund Legacy Projects",
      subtitle: "Niger Delta Development Commission",
      link: "/news"
    },
    {
      id: 3,
      image: "https://images.pexels.com/photos/159306/construction-site-build-construction-work-159306.jpeg?auto=compress&cs=tinysrgb&w=1600",
      title: "NDDC Applauds Senate for Passing N1.911trillion 2024 Budget",
      subtitle: "Niger Delta Development Commission",
      link: "/news"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <section className="relative h-[400px] sm:h-[500px] md:h-[600px] overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{ backgroundImage: `url(${slide.image})` }}
          >
            <div className="absolute inset-0 bg-black bg-opacity-50"></div>
          </div>
          <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
            <div className="max-w-4xl text-white">
              <div className="text-sm sm:text-lg md:text-xl mb-2 sm:mb-4 animate-fade-in">
                {slide.subtitle}
              </div>
              <h1 className="text-xl sm:text-3xl md:text-5xl font-bold mb-4 sm:mb-6 leading-tight animate-fade-in">
                {slide.title}
              </h1>
              <a
                href={slide.link}
                className="inline-flex items-center bg-green-600 text-white px-4 sm:px-8 py-2 sm:py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors animate-fade-in text-sm sm:text-base"
              >
                Learn More
                <ArrowRight className="ml-2" size={16} />
              </a>
            </div>
          </div>
        </div>
      ))}

      {/* Progress Bar */}
      <div className="absolute bottom-0 left-0 w-full h-1 bg-white bg-opacity-30">
        <div
          className="h-full bg-green-600 transition-all duration-5000 ease-linear"
          style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
        ></div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-4 sm:bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full transition-colors ${
              index === currentSlide ? 'bg-green-600' : 'bg-white bg-opacity-50'
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroSlider;