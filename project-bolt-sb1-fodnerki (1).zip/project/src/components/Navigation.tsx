import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronDown } from 'lucide-react';

interface NavigationProps {
  mobile?: boolean;
}

const Navigation = ({ mobile = false }: NavigationProps) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  const navItems = [
    { name: 'Home', href: '/' },
    {
      name: 'Who We Are',
      href: '#',
      subItems: [
        { name: 'Our Mission', href: '/our-mission' },
        { name: 'Our Board', href: '/our-board' },
      ],
    },
    {
      name: 'What We Do',
      href: '#',
      subItems: [
        { name: 'Projects', href: '/projects' },
      ],
    },
    { name: 'News', href: '/news' },
    {
      name: 'Supply',
      href: '#',
      subItems: [
        { name: 'Supply Procedure', href: '/supply-procedure' },
        { name: 'Supply Requirements', href: '/supply-requirements' },
      ],
    },
  ];

  const handleDropdownToggle = (itemName: string) => {
    setActiveDropdown(activeDropdown === itemName ? null : itemName);
  };

  const isActiveLink = (href: string) => {
    return location.pathname === href;
  };

  if (mobile) {
    return (
      <div className="px-4 py-2 bg-white border-t max-h-96 overflow-y-auto">
        {navItems.map((item) => (
          <div key={item.name} className="py-1">
            {item.subItems ? (
              <>
                <button
                  onClick={() => handleDropdownToggle(item.name)}
                  className="flex justify-between items-center w-full text-left py-3 px-3 text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md text-sm sm:text-base"
                >
                  {item.name}
                  <ChevronDown
                    size={16}
                    className={`transition-transform ${
                      activeDropdown === item.name ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {activeDropdown === item.name && (
                  <div className="pl-4 py-2 space-y-1">
                    {item.subItems.map((subItem) => (
                      <Link
                        key={subItem.name}
                        to={subItem.href}
                        className={`block py-2 px-3 rounded-md text-sm ${
                          isActiveLink(subItem.href)
                            ? 'text-green-600 bg-green-50'
                            : 'text-gray-600 hover:text-green-600 hover:bg-green-50'
                        }`}
                      >
                        {subItem.name}
                      </Link>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <Link
                to={item.href}
                className={`block py-3 px-3 rounded-md text-sm sm:text-base ${
                  isActiveLink(item.href)
                    ? 'text-green-600 bg-green-50'
                    : 'text-gray-700 hover:text-green-600 hover:bg-green-50'
                }`}
              >
                {item.name}
              </Link>
            )}
          </div>
        ))}
      </div>
    );
  }

  return (
    <nav className="flex space-x-6 xl:space-x-8">
      {navItems.map((item) => (
        <div key={item.name} className="relative group">
          {item.subItems ? (
            <div
              onMouseEnter={() => setActiveDropdown(item.name)}
              onMouseLeave={() => setActiveDropdown(null)}
              className="relative"
            >
              <button className="flex items-center space-x-1 text-gray-700 hover:text-green-600 py-2 transition-colors text-sm xl:text-base">
                <span>{item.name}</span>
                <ChevronDown size={16} />
              </button>

              {activeDropdown === item.name && (
                <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-50">
                  {item.subItems.map((subItem) => (
                    <Link
                      key={subItem.name}
                      to={subItem.href}
                      className={`block px-4 py-3 transition-colors text-sm hover:bg-green-50 first:rounded-t-md last:rounded-b-md ${
                        isActiveLink(subItem.href)
                          ? 'bg-green-50 text-green-600 font-medium'
                          : 'text-gray-700 hover:text-green-600'
                      }`}
                    >
                      {subItem.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <Link
              to={item.href}
              className={`py-2 transition-colors text-sm xl:text-base ${
                isActiveLink(item.href)
                  ? 'text-green-600 font-medium'
                  : 'text-gray-700 hover:text-green-600'
              }`}
            >
              {item.name}
            </Link>
          )}
        </div>
      ))}
    </nav>
  );
};

export default Navigation;