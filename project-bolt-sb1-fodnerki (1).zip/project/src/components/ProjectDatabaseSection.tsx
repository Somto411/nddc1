import React from 'react';
import { Play, ArrowRight } from 'lucide-react';

const ProjectDatabaseSection = () => {
  return (
    <section 
      className="py-20 relative"
      style={{
        backgroundImage: "linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.pexels.com/photos/159306/construction-site-build-construction-work-159306.jpeg?auto=compress&cs=tinysrgb&w=1600')",
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-green-400 font-medium mb-2">Government Service</div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Explore our Online<br />
              Project Database<br />
              & Resources
            </h2>
            <p className="text-gray-300 text-lg mb-8 leading-relaxed">
              Get current updates on our Projects and Programs cut across the Nine States of the Niger Delta Region, 
              gain deep insights and analysis of developmental trends within the region and the impact of our Projects 
              and Programs on our people along with developmental projections
            </p>
            <a
              href="/project-database"
              className="inline-flex items-center bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
            >
              Search Our Project Database
              <ArrowRight className="ml-2" size={20} />
            </a>
          </div>

          <div className="relative">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-8 text-center">
              <div className="relative mb-6">
                <img
                  src="https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Project Database Chart"
                  className="w-full h-64 object-cover rounded-lg"
                />
                <button className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center rounded-lg hover:bg-opacity-40 transition-colors">
                  <div className="bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center hover:bg-green-700 transition-colors">
                    <Play size={24} />
                  </div>
                </button>
              </div>
              <a
                href="/project-database"
                className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
              >
                Discover More
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectDatabaseSection;