import React, { useState } from 'react';
import { FileText, CheckCircle, AlertTriangle, Download, Search, Filter } from 'lucide-react';

const SupplyRequirements = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'construction', name: 'Construction' },
    { id: 'consulting', name: 'Consulting Services' },
    { id: 'goods', name: 'Goods & Equipment' },
    { id: 'maintenance', name: 'Maintenance Services' }
  ];

  const requirements = [
    {
      id: 1,
      category: 'construction',
      title: 'Road Construction Projects',
      minExperience: '10 years',
      minNetWorth: '₦500 Million',
      bondRequirement: '10% of contract value',
      specificRequirements: [
        'COREN registration for key personnel',
        'Minimum of 5 similar projects completed',
        'Equipment ownership or lease agreements',
        'Environmental compliance certification'
      ],
      documents: [
        'Certificate of Incorporation',
        'Tax Clearance Certificate (3 years)',
        'Audited Financial Statements (3 years)',
        'Equipment list with proof of ownership',
        'Project portfolio with completion certificates'
      ]
    },
    {
      id: 2,
      category: 'construction',
      title: 'Building Construction',
      minExperience: '8 years',
      minNetWorth: '₦300 Million',
      bondRequirement: '10% of contract value',
      specificRequirements: [
        'NIOB registration',
        'Minimum of 3 similar building projects',
        'Quality management system certification',
        'Safety management certification'
      ],
      documents: [
        'Certificate of Incorporation',
        'Tax Clearance Certificate (3 years)',
        'Audited Financial Statements (3 years)',
        'NIOB registration certificate',
        'ISO certifications (if applicable)'
      ]
    },
    {
      id: 3,
      category: 'consulting',
      title: 'Engineering Consulting Services',
      minExperience: '5 years',
      minNetWorth: '₦100 Million',
      bondRequirement: '5% of contract value',
      specificRequirements: [
        'ACEN registration',
        'Professional indemnity insurance',
        'Minimum of 3 similar consulting projects',
        'Key personnel with relevant qualifications'
      ],
      documents: [
        'Certificate of Incorporation',
        'Tax Clearance Certificate (3 years)',
        'ACEN registration certificate',
        'Professional indemnity insurance',
        'CVs of key personnel'
      ]
    },
    {
      id: 4,
      category: 'goods',
      title: 'Medical Equipment Supply',
      minExperience: '3 years',
      minNetWorth: '₦50 Million',
      bondRequirement: '5% of contract value',
      specificRequirements: [
        'NAFDAC registration (where applicable)',
        'Manufacturer authorization letters',
        'After-sales service capability',
        'Warranty provisions'
      ],
      documents: [
        'Certificate of Incorporation',
        'Tax Clearance Certificate (3 years)',
        'Manufacturer authorization',
        'Product catalogues and specifications',
        'After-sales service agreement'
      ]
    },
    {
      id: 5,
      category: 'maintenance',
      title: 'Facility Maintenance Services',
      minExperience: '3 years',
      minNetWorth: '₦25 Million',
      bondRequirement: '5% of contract value',
      specificRequirements: [
        'Trained technical personnel',
        'Emergency response capability',
        'Equipment and tools inventory',
        'Safety protocols and procedures'
      ],
      documents: [
        'Certificate of Incorporation',
        'Tax Clearance Certificate (3 years)',
        'Personnel training certificates',
        'Equipment inventory list',
        'Safety management procedures'
      ]
    }
  ];

  const filteredRequirements = requirements.filter(req => {
    const matchesCategory = selectedCategory === 'all' || req.category === selectedCategory;
    const matchesSearch = req.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const generalRequirements = [
    {
      title: 'Legal Requirements',
      items: [
        'Valid Certificate of Incorporation',
        'Current Tax Clearance Certificate',
        'VAT registration certificate',
        'Pension compliance certificate'
      ]
    },
    {
      title: 'Financial Requirements',
      items: [
        'Audited financial statements (last 3 years)',
        'Bank statements (last 6 months)',
        'Evidence of financial capacity',
        'Credit rating (if available)'
      ]
    },
    {
      title: 'Technical Requirements',
      items: [
        'Relevant professional registrations',
        'Technical personnel qualifications',
        'Equipment and facility ownership',
        'Quality management systems'
      ]
    },
    {
      title: 'Experience Requirements',
      items: [
        'Portfolio of similar projects',
        'Client reference letters',
        'Project completion certificates',
        'Performance evaluation reports'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Supply Requirements</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Comprehensive requirements and qualifications for participating in NDDC procurement opportunities
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search requirements..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* General Requirements Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">General Requirements</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Basic requirements that apply to all categories of procurement at NDDC
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {generalRequirements.map((section, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{section.title}</h3>
                <ul className="space-y-2">
                  {section.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start text-sm">
                      <CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={14} />
                      <span className="text-gray-600">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Specific Requirements by Category */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Category-Specific Requirements</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Detailed requirements for different categories of procurement
            </p>
          </div>

          <div className="space-y-8">
            {filteredRequirements.map((requirement) => (
              <div key={requirement.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{requirement.title}</h3>
                      <span className="inline-block bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                        {categories.find(cat => cat.id === requirement.category)?.name}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Minimum Experience</h4>
                      <p className="text-blue-600 font-medium">{requirement.minExperience}</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Minimum Net Worth</h4>
                      <p className="text-green-600 font-medium">{requirement.minNetWorth}</p>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Bond Requirement</h4>
                      <p className="text-orange-600 font-medium">{requirement.bondRequirement}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Specific Requirements</h4>
                      <ul className="space-y-2">
                        {requirement.specificRequirements.map((req, index) => (
                          <li key={index} className="flex items-start text-sm">
                            <AlertTriangle className="text-orange-500 mr-2 mt-0.5 flex-shrink-0" size={14} />
                            <span className="text-gray-600">{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Required Documents</h4>
                      <ul className="space-y-2">
                        {requirement.documents.map((doc, index) => (
                          <li key={index} className="flex items-start text-sm">
                            <FileText className="text-blue-500 mr-2 mt-0.5 flex-shrink-0" size={14} />
                            <span className="text-gray-600">{doc}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredRequirements.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Filter size={48} className="mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No requirements found</h3>
              <p className="text-gray-600">Try adjusting your search terms or category filter.</p>
            </div>
          )}
        </div>
      </section>

      {/* Qualification Process */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Qualification Process</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Steps to qualify for NDDC procurement opportunities
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">1</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Document Preparation</h3>
              <p className="text-gray-600 text-sm">
                Gather all required documents and ensure they meet NDDC standards
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">2</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Pre-qualification</h3>
              <p className="text-gray-600 text-sm">
                Submit pre-qualification application for relevant categories
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">3</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Evaluation</h3>
              <p className="text-gray-600 text-sm">
                NDDC evaluates application against set criteria and requirements
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 font-bold text-xl">4</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Certification</h3>
              <p className="text-gray-600 text-sm">
                Successful applicants receive pre-qualification certificates
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Download Section */}
      <section className="py-16 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Download Requirements Guide</h2>
          <p className="text-green-100 mb-8 max-w-2xl mx-auto">
            Get the complete requirements guide with detailed specifications for all procurement categories
          </p>
          <button className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors inline-flex items-center">
            <Download className="mr-2" size={20} />
            Download Complete Guide (PDF)
          </button>
        </div>
      </section>
    </div>
  );
};

export default SupplyRequirements;