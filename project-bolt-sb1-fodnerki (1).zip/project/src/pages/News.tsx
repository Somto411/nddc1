import React, { useState } from 'react';
import { Calendar, ArrowRight, Search, Tag } from 'lucide-react';

const News = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { id: 'all', name: 'All News' },
    { id: 'tenders', name: 'Tenders & Procurement' },
    { id: 'projects', name: 'Project Updates' },
    { id: 'announcements', name: 'Announcements' },
    { id: 'scholarships', name: 'Scholarships' }
  ];

  const newsArticles = [
    {
      id: 1,
      title: "NDDC Announces ₦50 Billion Infrastructure Development Tender",
      excerpt: "The Niger Delta Development Commission has announced a major infrastructure development tender worth ₦50 billion for the construction of roads, bridges, and drainage systems across the Niger Delta region.",
      date: "December 20, 2024",
      category: "tenders",
      image: "https://images.pexels.com/photos/1117452/pexels-photo-1117452.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: true
    },
    {
      id: 2,
      title: "East-West Road Project Reaches 75% Completion",
      excerpt: "The ongoing rehabilitation of the East-West Road has achieved a significant milestone with 75% completion. The project is expected to be fully completed by Q2 2024.",
      date: "December 18, 2024",
      category: "projects",
      image: "https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      id: 3,
      title: "2024 NDDC Scholarship Program Application Deadline Extended",
      excerpt: "Due to overwhelming response, the application deadline for the 2024 NDDC Scholarship Program has been extended to January 31, 2025. Over 50,000 applications have been received.",
      date: "December 15, 2024",
      category: "scholarships",
      image: "https://images.pexels.com/photos/267885/pexels-photo-267885.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      id: 4,
      title: "New Procurement Guidelines for 2024 Released",
      excerpt: "NDDC has released updated procurement guidelines for 2024, emphasizing transparency, local content participation, and environmental sustainability in all projects.",
      date: "December 12, 2024",
      category: "announcements",
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      id: 5,
      title: "Rural Electrification Project Benefits 100 Communities",
      excerpt: "The NDDC rural electrification project has successfully brought electricity to 100 communities across Delta, Bayelsa, and Rivers states, improving quality of life for over 500,000 residents.",
      date: "December 10, 2024",
      category: "projects",
      image: "https://images.pexels.com/photos/2159065/pexels-photo-2159065.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      id: 6,
      title: "Tender Opening for Hospital Construction Projects",
      excerpt: "NDDC invites qualified contractors to bid for the construction of three modern hospitals in Akwa Ibom, Cross River, and Edo states. Total project value: ₦30 billion.",
      date: "December 8, 2024",
      category: "tenders",
      image: "https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      id: 7,
      title: "NDDC Partners with International Development Organizations",
      excerpt: "Strategic partnerships established with World Bank and African Development Bank to enhance project funding and technical expertise for Niger Delta development.",
      date: "December 5, 2024",
      category: "announcements",
      image: "https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      id: 8,
      title: "Environmental Impact Assessment for New Projects Completed",
      excerpt: "Comprehensive environmental impact assessments have been completed for upcoming infrastructure projects, ensuring sustainable development practices.",
      date: "December 3, 2024",
      category: "projects",
      image: "https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    }
  ];

  const filteredNews = newsArticles.filter(article => {
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredNews = newsArticles.filter(article => article.featured);
  const regularNews = filteredNews.filter(article => !article.featured);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'tenders':
        return 'bg-green-100 text-green-800';
      case 'projects':
        return 'bg-blue-100 text-blue-800';
      case 'announcements':
        return 'bg-purple-100 text-purple-800';
      case 'scholarships':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">News & Updates</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Stay informed about the latest developments, announcements, and opportunities from NDDC
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search news..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured News */}
      {featuredNews.length > 0 && selectedCategory === 'all' && (
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Featured News</h2>
            {featuredNews.map((article) => (
              <div key={article.id} className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
                <div className="md:flex">
                  <div className="md:w-1/3">
                    <img
                      src={article.image}
                      alt={article.title}
                      className="w-full h-64 md:h-full object-cover"
                    />
                  </div>
                  <div className="md:w-2/3 p-8">
                    <div className="flex items-center mb-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(article.category)}`}>
                        {categories.find(cat => cat.id === article.category)?.name}
                      </span>
                      <div className="flex items-center ml-4 text-gray-500 text-sm">
                        <Calendar size={16} className="mr-2" />
                        {article.date}
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">{article.title}</h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">{article.excerpt}</p>
                    <a
                      href="#"
                      className="inline-flex items-center text-green-600 hover:text-green-700 font-semibold"
                    >
                      Read Full Article
                      <ArrowRight className="ml-2" size={16} />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Regular News Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900">
              {selectedCategory === 'all' ? 'Latest News' : `${categories.find(cat => cat.id === selectedCategory)?.name}`}
            </h2>
            <div className="text-gray-600">
              {filteredNews.length} article{filteredNews.length !== 1 ? 's' : ''} found
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {regularNews.map((article) => (
              <article key={article.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-w-16 aspect-h-9">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-48 object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(article.category)}`}>
                      {categories.find(cat => cat.id === article.category)?.name}
                    </span>
                    <div className="flex items-center text-gray-500 text-sm">
                      <Calendar size={14} className="mr-1" />
                      {article.date}
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 hover:text-green-600 cursor-pointer line-clamp-2">
                    {article.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">{article.excerpt}</p>
                  <a
                    href="#"
                    className="inline-flex items-center text-green-600 hover:text-green-700 font-semibold text-sm"
                  >
                    Read More
                    <ArrowRight className="ml-2" size={14} />
                  </a>
                </div>
              </article>
            ))}
          </div>

          {filteredNews.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Tag size={48} className="mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
              <p className="text-gray-600">Try adjusting your search terms or category filter.</p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Subscription */}
      <section className="py-16 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Stay Updated</h2>
          <p className="text-green-100 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter to receive the latest news, tender announcements, and project updates directly in your inbox.
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 px-4 py-3 rounded-lg border-0 focus:ring-2 focus:ring-green-300"
            />
            <button className="bg-green-800 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-900 transition-colors">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default News;