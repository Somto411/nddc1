import React, { useState } from 'react';
import { MapPin, Calendar, DollarSign, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const Projects = () => {
  const [activeTab, setActiveTab] = useState('ongoing');

  const projects = {
    ongoing: [
      {
        id: 1,
        title: "East-West Road Rehabilitation Project",
        location: "Rivers, Bayelsa, Delta States",
        budget: "₦150 Billion",
        startDate: "January 2023",
        completion: "75%",
        description: "Comprehensive rehabilitation of the East-West Road spanning 338km across three states.",
        contractor: "Julius Berger Nigeria PLC",
        status: "ongoing"
      },
      {
        id: 2,
        title: "Niger Delta University Teaching Hospital",
        location: "Bayelsa State",
        budget: "₦25 Billion",
        startDate: "March 2023",
        completion: "45%",
        description: "Construction of a world-class teaching hospital with modern medical facilities.",
        contractor: "RCC Limited",
        status: "ongoing"
      },
      {
        id: 3,
        title: "Ogbomoso-Ilorin Road Project",
        location: "Kwara State",
        budget: "₦18 Billion",
        startDate: "June 2023",
        completion: "30%",
        description: "Construction and rehabilitation of 47km dual carriageway.",
        contractor: "Arab Contractors",
        status: "ongoing"
      }
    ],
    completed: [
      {
        id: 4,
        title: "Port Harcourt-Aba Expressway",
        location: "Rivers, Abia States",
        budget: "₦75 Billion",
        startDate: "January 2020",
        completion: "100%",
        description: "Complete reconstruction of 51km dual carriageway with modern drainage systems.",
        contractor: "Julius Berger Nigeria PLC",
        status: "completed"
      },
      {
        id: 5,
        title: "Warri-Benin Road Rehabilitation",
        location: "Delta, Edo States",
        budget: "₦45 Billion",
        startDate: "September 2019",
        completion: "100%",
        description: "Rehabilitation of 120km federal highway with improved safety features.",
        contractor: "Setraco Nigeria Limited",
        status: "completed"
      }
    ],
    planned: [
      {
        id: 6,
        title: "Calabar-Itu Highway Construction",
        location: "Cross River, Akwa Ibom States",
        budget: "₦95 Billion",
        startDate: "Q2 2024",
        completion: "0%",
        description: "Construction of new 85km highway to improve interstate connectivity.",
        contractor: "Tender in Progress",
        status: "planned"
      },
      {
        id: 7,
        title: "Yenagoa International Airport Expansion",
        location: "Bayelsa State",
        budget: "₦35 Billion",
        startDate: "Q3 2024",
        completion: "0%",
        description: "Expansion and modernization of airport facilities to international standards.",
        contractor: "Tender in Progress",
        status: "planned"
      }
    ]
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="text-green-600" size={20} />;
      case 'ongoing':
        return <Clock className="text-blue-600" size={20} />;
      case 'planned':
        return <AlertCircle className="text-orange-600" size={20} />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'ongoing':
        return 'bg-blue-100 text-blue-800';
      case 'planned':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Projects</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Transforming the Niger Delta through strategic infrastructure development and community-focused initiatives
            </p>
          </div>
        </div>
      </section>

      {/* Project Statistics */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">150+</div>
              <div className="text-gray-700 font-medium">Total Projects</div>
            </div>
            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <div className="text-3xl font-bold text-blue-600 mb-2">45</div>
              <div className="text-gray-700 font-medium">Ongoing Projects</div>
            </div>
            <div className="text-center p-6 bg-orange-50 rounded-lg">
              <div className="text-3xl font-bold text-orange-600 mb-2">25</div>
              <div className="text-gray-700 font-medium">Planned Projects</div>
            </div>
            <div className="text-center p-6 bg-purple-50 rounded-lg">
              <div className="text-3xl font-bold text-purple-600 mb-2">₦2.5T</div>
              <div className="text-gray-700 font-medium">Total Investment</div>
            </div>
          </div>
        </div>
      </section>

      {/* Project Categories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Project Portfolio</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Browse our comprehensive project portfolio across different phases of development
            </p>
          </div>

          {/* Tab Navigation */}
          <div className="flex justify-center mb-8">
            <div className="bg-white rounded-lg p-1 shadow-md">
              <button
                onClick={() => setActiveTab('ongoing')}
                className={`px-6 py-3 rounded-md font-medium transition-colors ${
                  activeTab === 'ongoing'
                    ? 'bg-green-600 text-white'
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                Ongoing Projects
              </button>
              <button
                onClick={() => setActiveTab('completed')}
                className={`px-6 py-3 rounded-md font-medium transition-colors ${
                  activeTab === 'completed'
                    ? 'bg-green-600 text-white'
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                Completed Projects
              </button>
              <button
                onClick={() => setActiveTab('planned')}
                className={`px-6 py-3 rounded-md font-medium transition-colors ${
                  activeTab === 'planned'
                    ? 'bg-green-600 text-white'
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                Planned Projects
              </button>
            </div>
          </div>

          {/* Project Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {projects[activeTab as keyof typeof projects].map((project) => (
              <div key={project.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-900 flex-1">{project.title}</h3>
                    <div className="flex items-center ml-4">
                      {getStatusIcon(project.status)}
                    </div>
                  </div>

                  <div className="space-y-3 mb-4">
                    <div className="flex items-center text-gray-600">
                      <MapPin size={16} className="mr-2 text-green-600" />
                      <span className="text-sm">{project.location}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <DollarSign size={16} className="mr-2 text-green-600" />
                      <span className="text-sm font-medium">{project.budget}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Calendar size={16} className="mr-2 text-green-600" />
                      <span className="text-sm">Started: {project.startDate}</span>
                    </div>
                  </div>

                  <p className="text-gray-600 text-sm mb-4 leading-relaxed">{project.description}</p>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">Contractor:</span> {project.contractor}
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
                        {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                      </span>
                      {project.status === 'ongoing' && (
                        <div className="text-sm font-medium text-blue-600">
                          {project.completion} Complete
                        </div>
                      )}
                    </div>
                  </div>

                  {project.status === 'ongoing' && (
                    <div className="mt-4">
                      <div className="bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: project.completion }}
                        ></div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Project Impact */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Project Impact</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our projects create lasting positive impact across the Niger Delta region
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="text-4xl font-bold text-green-600 mb-3">2.5M+</div>
              <div className="text-lg font-semibold text-gray-900 mb-2">People Benefited</div>
              <p className="text-gray-600 text-sm">
                Direct and indirect beneficiaries of our development projects
              </p>
            </div>

            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <div className="text-4xl font-bold text-blue-600 mb-3">15,000+</div>
              <div className="text-lg font-semibold text-gray-900 mb-2">Jobs Created</div>
              <p className="text-gray-600 text-sm">
                Employment opportunities generated through project implementation
              </p>
            </div>

            <div className="text-center p-6 bg-orange-50 rounded-lg">
              <div className="text-4xl font-bold text-orange-600 mb-3">500+</div>
              <div className="text-lg font-semibold text-gray-900 mb-2">Communities Reached</div>
              <p className="text-gray-600 text-sm">
                Communities directly impacted by infrastructure development
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;