import React, { useState } from 'react';
import { Search, Filter, MapPin, Calendar, DollarSign, User, Eye, Download } from 'lucide-react';

const ProjectDatabase = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedState, setSelectedState] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const states = [
    'All States', 'Abia', 'Akwa Ibom', 'Bayelsa', 'Cross River', 'Delta', 'Edo', 'Imo', 'Ondo', 'Rivers'
  ];

  const statuses = ['All Status', 'Ongoing', 'Completed', 'Planned', 'Suspended'];
  const categories = ['All Categories', 'Infrastructure', 'Education', 'Healthcare', 'Environment', 'Agriculture'];

  const projects = [
    {
      id: 'NDDC/2023/001',
      title: 'East-West Road Rehabilitation (Section A)',
      description: 'Rehabilitation of 85km section of East-West Road from Port Harcourt to Aba',
      state: 'Rivers',
      lga: 'Port Harcourt',
      category: 'Infrastructure',
      contractor: 'Julius Berger Nigeria PLC',
      contractValue: '₦75,000,000,000',
      startDate: '2023-01-15',
      expectedCompletion: '2024-12-31',
      actualCompletion: null,
      status: 'Ongoing',
      progress: 75,
      beneficiaries: 500000,
      coordinates: { lat: 4.8156, lng: 7.0498 }
    },
    {
      id: 'NDDC/2022/045',
      title: 'Niger Delta University Teaching Hospital',
      description: 'Construction of 500-bed teaching hospital with modern medical equipment',
      state: 'Bayelsa',
      lga: 'Yenagoa',
      category: 'Healthcare',
      contractor: 'RCC Limited',
      contractValue: '₦25,000,000,000',
      startDate: '2022-03-10',
      expectedCompletion: '2024-06-30',
      actualCompletion: null,
      status: 'Ongoing',
      progress: 45,
      beneficiaries: 200000,
      coordinates: { lat: 4.9267, lng: 6.2676 }
    },
    {
      id: 'NDDC/2021/078',
      title: 'Warri-Benin Road Rehabilitation',
      description: 'Complete rehabilitation of 120km Warri-Benin federal highway',
      state: 'Delta',
      lga: 'Warri',
      category: 'Infrastructure',
      contractor: 'Setraco Nigeria Limited',
      contractValue: '₦45,000,000,000',
      startDate: '2021-09-01',
      expectedCompletion: '2023-08-31',
      actualCompletion: '2023-08-15',
      status: 'Completed',
      progress: 100,
      beneficiaries: 750000,
      coordinates: { lat: 5.5160, lng: 5.7500 }
    },
    {
      id: 'NDDC/2023/089',
      title: 'Akwa Ibom State University Expansion',
      description: 'Construction of new faculty buildings and student hostels',
      state: 'Akwa Ibom',
      lga: 'Mkpat Enin',
      category: 'Education',
      contractor: 'Arab Contractors',
      contractValue: '₦18,000,000,000',
      startDate: '2023-06-01',
      expectedCompletion: '2025-05-31',
      actualCompletion: null,
      status: 'Ongoing',
      progress: 30,
      beneficiaries: 25000,
      coordinates: { lat: 4.8447, lng: 7.5243 }
    },
    {
      id: 'NDDC/2024/012',
      title: 'Calabar International Airport Expansion',
      description: 'Expansion and modernization of Calabar airport to international standards',
      state: 'Cross River',
      lga: 'Calabar',
      category: 'Infrastructure',
      contractor: 'Tender in Progress',
      contractValue: '₦35,000,000,000',
      startDate: '2024-04-01',
      expectedCompletion: '2026-03-31',
      actualCompletion: null,
      status: 'Planned',
      progress: 0,
      beneficiaries: 300000,
      coordinates: { lat: 4.9517, lng: 8.3417 }
    },
    {
      id: 'NDDC/2022/156',
      title: 'Mangrove Restoration Project',
      description: 'Restoration of 10,000 hectares of mangrove forest in Niger Delta',
      state: 'Bayelsa',
      lga: 'Brass',
      category: 'Environment',
      contractor: 'Green Earth Consortium',
      contractValue: '₦8,000,000,000',
      startDate: '2022-11-01',
      expectedCompletion: '2024-10-31',
      actualCompletion: null,
      status: 'Ongoing',
      progress: 60,
      beneficiaries: 100000,
      coordinates: { lat: 4.3067, lng: 6.2333 }
    }
  ];

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.contractor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesState = selectedState === 'all' || project.state === selectedState;
    const matchesStatus = selectedStatus === 'all' || project.status === selectedStatus;
    const matchesCategory = selectedCategory === 'all' || project.category === selectedCategory;
    
    return matchesSearch && matchesState && matchesStatus && matchesCategory;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-green-100 text-green-800';
      case 'Ongoing':
        return 'bg-blue-100 text-blue-800';
      case 'Planned':
        return 'bg-orange-100 text-orange-800';
      case 'Suspended':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: string) => {
    return amount.replace(/₦(\d+),?(\d+),?(\d+),?(\d+)/, (match, ...groups) => {
      const number = groups.filter(g => g).join('');
      const billions = Math.floor(number / 1000000000);
      const millions = Math.floor((number % 1000000000) / 1000000);
      
      if (billions > 0) {
        return `₦${billions}.${Math.floor(millions / 100)}B`;
      } else {
        return `₦${Math.floor(number / 1000000)}M`;
      }
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Project Database</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Comprehensive database of NDDC projects across the Niger Delta region
            </p>
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">{projects.length}</div>
              <div className="text-gray-700 font-medium">Total Projects</div>
            </div>
            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {projects.filter(p => p.status === 'Ongoing').length}
              </div>
              <div className="text-gray-700 font-medium">Ongoing Projects</div>
            </div>
            <div className="text-center p-6 bg-orange-50 rounded-lg">
              <div className="text-3xl font-bold text-orange-600 mb-2">
                {projects.filter(p => p.status === 'Completed').length}
              </div>
              <div className="text-gray-700 font-medium">Completed Projects</div>
            </div>
            <div className="text-center p-6 bg-purple-50 rounded-lg">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {projects.reduce((sum, p) => sum + p.beneficiaries, 0).toLocaleString()}
              </div>
              <div className="text-gray-700 font-medium">Total Beneficiaries</div>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search projects..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
            </div>

            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              {states.map((state, index) => (
                <option key={index} value={index === 0 ? 'all' : state}>
                  {state}
                </option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              {statuses.map((status, index) => (
                <option key={index} value={index === 0 ? 'all' : status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              {categories.map((category, index) => (
                <option key={index} value={index === 0 ? 'all' : category}>
                  {category}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-4 flex justify-between items-center">
            <div className="text-gray-600">
              Showing {filteredProjects.length} of {projects.length} projects
            </div>
            <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center">
              <Download className="mr-2" size={16} />
              Export Data
            </button>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {filteredProjects.map((project) => (
              <div key={project.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <span className="text-sm text-gray-500 font-mono">{project.id}</span>
                        <span className={`ml-3 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
                          {project.status}
                        </span>
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{project.title}</h3>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">{project.description}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin size={16} className="mr-2 text-green-600" />
                      <span>{project.state}, {project.lga}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <DollarSign size={16} className="mr-2 text-green-600" />
                      <span className="font-medium">{formatCurrency(project.contractValue)}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <User size={16} className="mr-2 text-green-600" />
                      <span>{project.contractor}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar size={16} className="mr-2 text-green-600" />
                      <span>{new Date(project.startDate).getFullYear()}</span>
                    </div>
                  </div>

                  {project.status === 'Ongoing' && (
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-gray-700">Progress</span>
                        <span className="text-sm font-medium text-blue-600">{project.progress}%</span>
                      </div>
                      <div className="bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${project.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">Beneficiaries:</span> {project.beneficiaries.toLocaleString()}
                    </div>
                    <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center text-sm">
                      <Eye className="mr-2" size={14} />
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Filter size={48} className="mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No projects found</h3>
              <p className="text-gray-600">Try adjusting your search terms or filters.</p>
            </div>
          )}
        </div>
      </section>

      {/* Quick Stats */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Project Impact by State</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Distribution of NDDC projects across Niger Delta states
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {states.slice(1).map((state) => {
              const stateProjects = projects.filter(p => p.state === state);
              const totalValue = stateProjects.reduce((sum, p) => {
                const value = parseInt(p.contractValue.replace(/[₦,]/g, ''));
                return sum + value;
              }, 0);

              return (
                <div key={state} className="text-center p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-semibold text-gray-900 mb-2">{state}</h3>
                  <div className="text-2xl font-bold text-green-600 mb-1">{stateProjects.length}</div>
                  <div className="text-xs text-gray-600">Projects</div>
                  <div className="text-sm font-medium text-gray-700 mt-2">
                    ₦{(totalValue / 1000000000).toFixed(1)}B
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProjectDatabase;