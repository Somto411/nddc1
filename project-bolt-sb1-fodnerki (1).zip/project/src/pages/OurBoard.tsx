import React from 'react';
import { Users, Award, Briefcase } from 'lucide-react';

const OurBoard = () => {
  const boardMembers = [
    {
      name: "Dr. Samuel Ogbuku",
      position: "Managing Director/Chief Executive Officer",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-MD.png",
      bio: "Dr. Ogbuku brings over 20 years of experience in development administration and project management."
    },
    {
      name: "Mr. Victor Antai",
      position: "Executive Director, Projects",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-EDP.png",
      bio: "An experienced engineer with expertise in infrastructure development and project execution."
    },
    {
      name: "Mr. Boma Iyaye",
      position: "Executive Director, Finance & Administration",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-EDFA.png",
      bio: "A financial expert with extensive experience in public sector financial management."
    },
    {
      name: "Mr. Chiedu Ebie",
      position: "Chairman, Board of Directors",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-Chair.png",
      bio: "A distinguished leader with vast experience in governance and regional development."
    },
    {
      name: "Pastor Abasiandikan Robert Nkono",
      position: "Board Member",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-AkwaIbom.png",
      bio: "A pastor and an academic and policy expert specializing in Niger Delta development issues."
    },
    {
      name: "Chief Eruba Dimgba",
      position: "Board Member",
      image: "https://www.nddcbidsandprocurement.org/assets/image/team/team-GB-Abia.png",
      bio: "A legal practitioner with expertise in corporate governance and regulatory compliance."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Board</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Meet the distinguished leaders guiding NDDC's mission for Niger Delta development
            </p>
          </div>
        </div>
      </section>

      {/* Board Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Leadership Excellence</h2>
            <p className="text-lg text-gray-700 max-w-4xl mx-auto leading-relaxed">
              The NDDC Board comprises experienced professionals from diverse backgrounds, bringing together 
              expertise in development administration, engineering, finance, law, and regional governance. 
              Our leadership team is committed to transparent and accountable stewardship of resources 
              for the sustainable development of the Niger Delta region.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Diverse Expertise</h3>
              <p className="text-gray-600">
                Board members bring varied professional backgrounds and regional representation
              </p>
            </div>

            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Proven Leadership</h3>
              <p className="text-gray-600">
                Demonstrated track record in governance, development, and public service
              </p>
            </div>

            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Strategic Vision</h3>
              <p className="text-gray-600">
                Committed to long-term sustainable development and transparent governance
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Board Members */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Board Members</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Meet the distinguished individuals leading NDDC's mission for regional transformation
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {boardMembers.map((member) => (
              <div key={member.name} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-w-3 aspect-h-4">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-64 object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{member.name}</h3>
                  <p className="text-green-600 font-medium mb-3">{member.position}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Governance Structure */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Governance Structure</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our governance framework ensures accountability, transparency, and effective oversight
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Board Responsibilities</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Strategic planning and policy formulation
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Oversight of project implementation
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Financial management and accountability
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Stakeholder engagement and relations
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Committee Structure</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Audit and Risk Committee
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Projects and Technical Committee
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Finance and General Purpose Committee
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    Human Resources Committee
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-green-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Board Meetings</h3>
              <p className="text-gray-600 mb-4">
                The Board meets quarterly to review progress, approve major decisions, and ensure 
                compliance with regulatory requirements and best practices in governance.
              </p>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-700 font-medium">Meeting Frequency:</span>
                  <span className="text-gray-600">Quarterly</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-700 font-medium">Special Meetings:</span>
                  <span className="text-gray-600">As Required</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-700 font-medium">Quorum:</span>
                  <span className="text-gray-600">Simple Majority</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default OurBoard;