import React, { useState } from 'react';
import { Search, X, Calendar, User, DollarSign, FileText, CheckCircle, Clock, AlertCircle, Download } from 'lucide-react';

interface TenderData {
  id: string;
  title: string;
  company: string;
  amount: string;
  status: string;
  submissionDate: string;
  openingDate: string;
  description: string;
  contactPerson: string;
  email: string;
  phone: string;
  documents: string[];
  evaluationStatus: string;
  validityPeriod: string;
}

const TenderConfirmation = () => {
  const [searchId, setSearchId] = useState('');
  const [selectedTender, setSelectedTender] = useState<TenderData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  // Mock data - In production, this would come from your API
  const mockTenderData: { [key: string]: TenderData } = {
    'TND/2024/001': {
      id: 'TND/2024/001',
      title: 'Construction of Calabar-Itu Highway',
      company: 'ABC Construction Ltd',
      amount: '₦95,000,000,000',
      status: 'Submitted',
      submissionDate: '2024-01-15',
      openingDate: '2024-02-15',
      description: 'Construction of new 85km highway to improve interstate connectivity between Cross River and Akwa Ibom states.',
      contactPerson: 'John Doe',
      email: 'john.doe@abcconstruction.com',
      phone: '+2347013253195',
      documents: ['Technical Proposal.pdf', 'Financial Proposal.pdf', 'Company Profile.pdf', 'Tax Clearance.pdf'],
      evaluationStatus: 'Under Review',
      validityPeriod: '90 days'
    },
    'TND/2024/002': {
      id: 'TND/2024/002',
      title: 'Supply of Medical Equipment for Teaching Hospital',
      company: 'MedEquip Nigeria Ltd',
      amount: '₦15,000,000,000',
      status: 'Evaluated',
      submissionDate: '2024-01-20',
      openingDate: '2024-02-20',
      description: 'Supply and installation of modern medical equipment for the Niger Delta University Teaching Hospital.',
      contactPerson: 'Jane Smith',
      email: 'jane.smith@medequip.ng',
      phone: '+2347013253195',
      documents: ['Equipment Specifications.pdf', 'Price List.pdf', 'Warranty Terms.pdf', 'Installation Plan.pdf'],
      evaluationStatus: 'Shortlisted',
      validityPeriod: '60 days'
    },
    'TND/2023/089': {
      id: 'TND/2023/089',
      title: 'Rural Electrification Project Phase 3',
      company: 'PowerGrid Solutions',
      amount: '₦28,000,000,000',
      status: 'Awarded',
      submissionDate: '2023-11-10',
      openingDate: '2023-12-10',
      description: 'Extension of electricity infrastructure to 50 rural communities across the Niger Delta region.',
      contactPerson: 'Mike Johnson',
      email: 'mike.johnson@powergrid.ng',
      phone: '+2347013253195',
      documents: ['Technical Design.pdf', 'Implementation Timeline.pdf', 'Cost Breakdown.pdf', 'Safety Plan.pdf'],
      evaluationStatus: 'Contract Awarded',
      validityPeriod: '120 days'
    }
  };

  const handleSearch = async () => {
    if (!searchId.trim()) {
      setError('Please enter a tender ID');
      return;
    }

    setIsLoading(true);
    setError('');

    // Simulate API call
    setTimeout(() => {
      const tenderData = mockTenderData[searchId.toUpperCase()];
      if (tenderData) {
        setSelectedTender(tenderData);
      } else {
        setError('Tender ID not found. Please check the ID and try again.');
      }
      setIsLoading(false);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const closeModal = () => {
    setSelectedTender(null);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Submitted':
        return <CheckCircle className="text-blue-600" size={20} />;
      case 'Evaluated':
        return <Clock className="text-orange-600" size={20} />;
      case 'Awarded':
        return <CheckCircle className="text-green-600" size={20} />;
      case 'Rejected':
        return <AlertCircle className="text-red-600" size={20} />;
      default:
        return <FileText className="text-gray-600" size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Submitted':
        return 'bg-blue-100 text-blue-800';
      case 'Evaluated':
        return 'bg-orange-100 text-orange-800';
      case 'Awarded':
        return 'bg-green-100 text-green-800';
      case 'Rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Tender Confirmation</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Enter your tender ID to check submission status and details
            </p>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Search Tender Submission</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Enter your tender reference ID to view submission details, status updates, and evaluation progress
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label htmlFor="tenderId" className="block text-sm font-medium text-gray-700 mb-2">
                  Tender Reference ID
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="text"
                    id="tenderId"
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="e.g., TND/2024/001"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-lg"
                  />
                </div>
              </div>
              <div className="flex items-end">
                <button
                  onClick={handleSearch}
                  disabled={isLoading}
                  className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? 'Searching...' : 'Search'}
                </button>
              </div>
            </div>

            {error && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-600">{error}</p>
              </div>
            )}

            <div className="mt-8 text-center">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Sample Tender IDs for Testing:</h3>
              <div className="flex flex-wrap justify-center gap-4">
                {Object.keys(mockTenderData).map((id) => (
                  <button
                    key={id}
                    onClick={() => setSearchId(id)}
                    className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors font-mono text-sm"
                  >
                    {id}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Modal */}
      {selectedTender && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" onClick={closeModal}>
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center">
                    {getStatusIcon(selectedTender.status)}
                    <h3 className="text-2xl font-bold text-gray-900 ml-3">
                      Tender Details
                    </h3>
                  </div>
                  <button
                    onClick={closeModal}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X size={24} />
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Basic Information */}
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">Basic Information</h4>
                      <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                        <div>
                          <span className="text-sm text-gray-500">Tender ID:</span>
                          <p className="font-mono font-semibold">{selectedTender.id}</p>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Title:</span>
                          <p className="font-semibold">{selectedTender.title}</p>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Company:</span>
                          <p>{selectedTender.company}</p>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Bid Amount:</span>
                          <p className="font-semibold text-green-600">{selectedTender.amount}</p>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Status:</span>
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedTender.status)}`}>
                            {selectedTender.status}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">Description</h4>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <p className="text-gray-700">{selectedTender.description}</p>
                      </div>
                    </div>
                  </div>

                  {/* Timeline and Contact */}
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">Timeline</h4>
                      <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                        <div className="flex items-center">
                          <Calendar size={16} className="text-green-600 mr-2" />
                          <div>
                            <span className="text-sm text-gray-500">Submission Date:</span>
                            <p>{selectedTender.submissionDate}</p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <Calendar size={16} className="text-blue-600 mr-2" />
                          <div>
                            <span className="text-sm text-gray-500">Opening Date:</span>
                            <p>{selectedTender.openingDate}</p>
                          </div>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Validity Period:</span>
                          <p>{selectedTender.validityPeriod}</p>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Evaluation Status:</span>
                          <p className="font-semibold text-blue-600">{selectedTender.evaluationStatus}</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">Contact Information</h4>
                      <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                        <div className="flex items-center">
                          <User size={16} className="text-gray-600 mr-2" />
                          <div>
                            <span className="text-sm text-gray-500">Contact Person:</span>
                            <p>{selectedTender.contactPerson}</p>
                          </div>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Email:</span>
                          <p className="text-blue-600">{selectedTender.email}</p>
                        </div>
                        <div>
                          <span className="text-sm text-gray-500">Phone:</span>
                          <p>{selectedTender.phone}</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">Submitted Documents</h4>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <ul className="space-y-2">
                          {selectedTender.documents.map((doc, index) => (
                            <li key={index} className="flex items-center justify-between">
                              <div className="flex items-center">
                                <FileText size={16} className="text-gray-600 mr-2" />
                                <span className="text-sm">{doc}</span>
                              </div>
                              <button className="text-green-600 hover:text-green-700">
                                <Download size={16} />
                              </button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  onClick={closeModal}
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Help Section */}
      <section className="py-16 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Need Help?</h2>
          <p className="text-green-100 mb-8 max-w-2xl mx-auto">
            If you cannot find your tender ID or need assistance with the confirmation process, 
            please contact our support team.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Email Support</h3>
              <p className="text-green-100">tenders@nddcbpdivc.com.ng</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Phone Support</h3>
              <p className="text-green-100">+2347013253195</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Office Hours</h3>
              <p className="text-green-100">Mon - Fri: 8:00 AM - 5:00 PM</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TenderConfirmation;