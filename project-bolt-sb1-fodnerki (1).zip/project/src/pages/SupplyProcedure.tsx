import React from 'react';
import { FileText, CheckCircle, Clock, AlertTriangle, Download, Users } from 'lucide-react';

const SupplyProcedure = () => {
  const procurementSteps = [
    {
      step: 1,
      title: "Procurement Planning",
      description: "Identification of procurement needs and budget allocation",
      duration: "2-4 weeks",
      icon: FileText
    },
    {
      step: 2,
      title: "Tender Advertisement",
      description: "Public advertisement of tender opportunities in national newspapers and NDDC website",
      duration: "1 week",
      icon: Users
    },
    {
      step: 3,
      title: "Pre-qualification",
      description: "Assessment of contractors' technical and financial capabilities",
      duration: "2-3 weeks",
      icon: CheckCircle
    },
    {
      step: 4,
      title: "Tender Submission",
      description: "Submission of technical and financial proposals by qualified bidders",
      duration: "4-6 weeks",
      icon: FileText
    },
    {
      step: 5,
      title: "Evaluation",
      description: "Technical and financial evaluation of submitted proposals",
      duration: "3-4 weeks",
      icon: Clock
    },
    {
      step: 6,
      title: "Award & Contract",
      description: "Contract award to successful bidder and contract signing",
      duration: "2-3 weeks",
      icon: CheckCircle
    }
  ];

  const documents = [
    {
      title: "Procurement Manual 2024",
      description: "Comprehensive guide to NDDC procurement processes and procedures",
      size: "2.5 MB",
      format: "PDF"
    },
    {
      title: "Tender Document Template",
      description: "Standard template for tender document preparation",
      size: "1.2 MB",
      format: "DOC"
    },
    {
      title: "Pre-qualification Criteria",
      description: "Detailed criteria for contractor pre-qualification assessment",
      size: "800 KB",
      format: "PDF"
    },
    {
      title: "Contract Terms & Conditions",
      description: "Standard contract terms and conditions for NDDC projects",
      size: "1.8 MB",
      format: "PDF"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Supply Procedure</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Transparent and efficient procurement processes ensuring fair competition and value for money
            </p>
          </div>
        </div>
      </section>

      {/* Overview */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Procurement Overview</h2>
            <div className="max-w-4xl mx-auto">
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                The Niger Delta Development Commission (NDDC) follows a transparent and competitive procurement 
                process in accordance with the Public Procurement Act 2007 and international best practices. 
                Our procurement procedures ensure fairness, transparency, and value for money in all transactions.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                All procurement activities are conducted through open competitive bidding, with clear evaluation 
                criteria and timelines to ensure equal opportunities for all qualified suppliers and contractors.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Transparency</h3>
              <p className="text-gray-600">
                Open and transparent processes with public advertisement and clear evaluation criteria
              </p>
            </div>

            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Fair Competition</h3>
              <p className="text-gray-600">
                Equal opportunities for all qualified bidders through competitive processes
              </p>
            </div>

            <div className="text-center p-6 bg-orange-50 rounded-lg">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-orange-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Efficiency</h3>
              <p className="text-gray-600">
                Streamlined processes with clear timelines and efficient evaluation procedures
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Procurement Process */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Procurement Process</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our step-by-step procurement process ensures transparency and efficiency from planning to contract award
            </p>
          </div>

          <div className="space-y-8">
            {procurementSteps.map((step, index) => (
              <div key={step.step} className="flex items-start space-x-6">
                <div className="flex-shrink-0">
                  <div className="bg-green-600 text-white rounded-full w-12 h-12 flex items-center justify-center font-bold">
                    {step.step}
                  </div>
                </div>
                <div className="flex-1 bg-white p-6 rounded-lg shadow-md">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <step.icon className="text-green-600 mr-3" size={24} />
                        <h3 className="text-xl font-semibold text-gray-900">{step.title}</h3>
                      </div>
                      <p className="text-gray-600 mb-2">{step.description}</p>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock size={16} className="mr-1" />
                        Duration: {step.duration}
                      </div>
                    </div>
                  </div>
                </div>
                {index < procurementSteps.length - 1 && (
                  <div className="flex-shrink-0 w-px h-16 bg-gray-300 ml-6"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Procurement Methods */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Procurement Methods</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Different procurement methods are used based on project value, complexity, and urgency
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Open Competitive Bidding</h3>
              <p className="text-gray-600 text-sm mb-4">
                For contracts above ₦50 million. Open to all qualified bidders with public advertisement.
              </p>
              <div className="text-sm text-green-600 font-medium">Threshold: ₦50M+</div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Selective Tendering</h3>
              <p className="text-gray-600 text-sm mb-4">
                For specialized contracts. Limited to pre-qualified contractors with proven expertise.
              </p>
              <div className="text-sm text-blue-600 font-medium">Threshold: ₦10M - ₦50M</div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Direct Procurement</h3>
              <p className="text-gray-600 text-sm mb-4">
                For emergency situations or specialized services. Limited competition with justification.
              </p>
              <div className="text-sm text-orange-600 font-medium">Threshold: Below ₦10M</div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Requirements */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Key Requirements for Bidders</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Essential requirements that all bidders must meet to participate in NDDC procurement processes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Technical Requirements</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Valid Certificate of Incorporation</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Tax Clearance Certificate (3 years)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Audited Financial Statements (3 years)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Evidence of similar project experience</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Professional certifications and licenses</span>
                </li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Financial Requirements</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Minimum net worth requirement</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Bank guarantee or performance bond</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Evidence of financial capacity</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Credit rating (if applicable)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-600 mr-3 mt-1" size={16} />
                  <span className="text-gray-600">Insurance coverage documentation</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Document Downloads */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Procurement Documents</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Download essential documents and templates for participating in NDDC procurement processes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {documents.map((doc, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{doc.title}</h3>
                    <p className="text-gray-600 text-sm mb-3">{doc.description}</p>
                    <div className="flex items-center text-sm text-gray-500">
                      <span className="mr-4">Size: {doc.size}</span>
                      <span>Format: {doc.format}</span>
                    </div>
                  </div>
                  <button className="ml-4 bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition-colors">
                    <Download size={20} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Need Assistance?</h2>
          <p className="text-green-100 mb-8 max-w-2xl mx-auto">
            Our procurement team is available to assist with questions about the procurement process, 
            requirements, and documentation.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Procurement Office</h3>
              <p className="text-green-100">procurement@nddcbpdivc.com.ng</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Helpline</h3>
              <p className="text-green-100">+2347013253195</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Office Hours</h3>
              <p className="text-green-100">Mon - Fri: 8:00 AM - 5:00 PM</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SupplyProcedure;