import React from 'react';
import HeroSlider from '../components/HeroSlider';
import DepartmentCards from '../components/DepartmentCards';
import AboutSection from '../components/AboutSection';
import UpdatesSection from '../components/UpdatesSection';
import CoreFocusSection from '../components/CoreFocusSection';
import LatestNews from '../components/LatestNews';
import ExecutivesSection from '../components/ExecutivesSection';
import PublicationsSection from '../components/PublicationsSection';
import ProjectDatabaseSection from '../components/ProjectDatabaseSection';
import StatsSection from '../components/StatsSection';
import VideosSection from '../components/VideosSection';
import ReportCenterSection from '../components/ReportCenterSection';

const Home = () => {
  return (
    <>
      <HeroSlider />
      <DepartmentCards />
      <AboutSection />
      <UpdatesSection />
      <CoreFocusSection />
      <LatestNews />
      <ExecutivesSection />
      <PublicationsSection />
      <ProjectDatabaseSection />
      <StatsSection />
      <VideosSection />
      <ReportCenterSection />
    </>
  );
};

export default Home;