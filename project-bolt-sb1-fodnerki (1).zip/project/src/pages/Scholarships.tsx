import React, { useState } from 'react';
import { GraduationCap, Calendar, Users, Award, Download, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const Scholarships = () => {
  const [activeTab, setActiveTab] = useState('available');

  const scholarshipPrograms = {
    available: [
      {
        id: 1,
        title: "NDDC Undergraduate Scholarship Program 2024",
        description: "Full scholarship for undergraduate studies in Nigerian universities for indigenes of Niger Delta states.",
        eligibility: [
          "Must be an indigene of Niger Delta states",
          "Minimum of 5 credits in WAEC/NECO including English and Mathematics",
          "JAMB score of 200 and above",
          "Age not exceeding 22 years"
        ],
        benefits: [
          "Full tuition fees",
          "Monthly stipend of ₦50,000",
          "Book allowance",
          "Accommodation support"
        ],
        deadline: "January 31, 2025",
        duration: "4-6 years",
        slots: 500,
        status: "Open"
      },
      {
        id: 2,
        title: "NDDC Postgraduate Scholarship Program 2024",
        description: "Scholarship for Master's and PhD programs in Nigerian and foreign universities.",
        eligibility: [
          "Must be an indigene of Niger Delta states",
          "First degree with minimum of Second Class Upper",
          "Age not exceeding 35 years for Masters, 40 years for PhD",
          "Relevant work experience preferred"
        ],
        benefits: [
          "Full tuition fees",
          "Monthly stipend",
          "Research allowance",
          "Thesis/dissertation support"
        ],
        deadline: "February 28, 2025",
        duration: "2-5 years",
        slots: 200,
        status: "Open"
      },
      {
        id: 3,
        title: "NDDC Skills Acquisition Program 2024",
        description: "Technical and vocational training program for youth empowerment and job creation.",
        eligibility: [
          "Must be an indigene of Niger Delta states",
          "Age between 18-35 years",
          "Minimum of SSCE certificate",
          "Interest in technical/vocational skills"
        ],
        benefits: [
          "Free training",
          "Training allowance",
          "Starter pack upon completion",
          "Job placement assistance"
        ],
        deadline: "March 15, 2025",
        duration: "6-12 months",
        slots: 1000,
        status: "Open"
      }
    ],
    closed: [
      {
        id: 4,
        title: "NDDC Medical Scholarship Program 2023",
        description: "Specialized scholarship for medical and health sciences students.",
        deadline: "December 31, 2023",
        duration: "6 years",
        slots: 100,
        status: "Closed"
      },
      {
        id: 5,
        title: "NDDC Engineering Scholarship Program 2023",
        description: "Scholarship for engineering students in petroleum, civil, and mechanical engineering.",
        deadline: "November 30, 2023",
        duration: "5 years",
        slots: 150,
        status: "Closed"
      }
    ]
  };

  const applicationSteps = [
    {
      step: 1,
      title: "Online Registration",
      description: "Create an account on the NDDC scholarship portal and complete your profile",
      icon: Users
    },
    {
      step: 2,
      title: "Document Upload",
      description: "Upload all required documents including certificates, transcripts, and identification",
      icon: CheckCircle
    },
    {
      step: 3,
      title: "Application Submission",
      description: "Complete and submit your scholarship application before the deadline",
      icon: Clock
    },
    {
      step: 4,
      title: "Screening & Interview",
      description: "Participate in the screening process and attend interviews if shortlisted",
      icon: Award
    }
  ];

  const requiredDocuments = [
    "Birth Certificate or Age Declaration",
    "Certificate of Origin/Indigeneship",
    "WAEC/NECO/NABTEB Certificate",
    "JAMB Result (for undergraduate)",
    "University Admission Letter",
    "First Degree Certificate (for postgraduate)",
    "Academic Transcripts",
    "Passport Photographs",
    "Medical Certificate",
    "Guarantor's Form"
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open':
        return 'bg-green-100 text-green-800';
      case 'Closed':
        return 'bg-red-100 text-red-800';
      case 'Coming Soon':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Scholarships</h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Empowering Niger Delta youth through quality education and skills development opportunities
            </p>
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">25,000+</div>
              <div className="text-gray-700 font-medium">Scholarships Awarded</div>
            </div>
            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <div className="text-3xl font-bold text-blue-600 mb-2">1,700</div>
              <div className="text-gray-700 font-medium">Available Slots 2024</div>
            </div>
            <div className="text-center p-6 bg-orange-50 rounded-lg">
              <div className="text-3xl font-bold text-orange-600 mb-2">95%</div>
              <div className="text-gray-700 font-medium">Completion Rate</div>
            </div>
            <div className="text-center p-6 bg-purple-50 rounded-lg">
              <div className="text-3xl font-bold text-purple-600 mb-2">₦15B</div>
              <div className="text-gray-700 font-medium">Total Investment</div>
            </div>
          </div>
        </div>
      </section>

      {/* Scholarship Programs */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Scholarship Programs</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore our comprehensive scholarship programs designed to support educational advancement
            </p>
          </div>

          {/* Tab Navigation */}
          <div className="flex justify-center mb-8">
            <div className="bg-white rounded-lg p-1 shadow-md">
              <button
                onClick={() => setActiveTab('available')}
                className={`px-6 py-3 rounded-md font-medium transition-colors ${
                  activeTab === 'available'
                    ? 'bg-green-600 text-white'
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                Available Programs
              </button>
              <button
                onClick={() => setActiveTab('closed')}
                className={`px-6 py-3 rounded-md font-medium transition-colors ${
                  activeTab === 'closed'
                    ? 'bg-green-600 text-white'
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                Closed Programs
              </button>
            </div>
          </div>

          {/* Scholarship Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {scholarshipPrograms[activeTab as keyof typeof scholarshipPrograms].map((program) => (
              <div key={program.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-900 flex-1">{program.title}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(program.status)}`}>
                      {program.status}
                    </span>
                  </div>

                  <p className="text-gray-600 mb-4">{program.description}</p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500 mb-1">Deadline</div>
                      <div className="font-medium text-gray-900">{program.deadline}</div>
                    </div>
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500 mb-1">Duration</div>
                      <div className="font-medium text-gray-900">{program.duration}</div>
                    </div>
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-500 mb-1">Available Slots</div>
                      <div className="font-medium text-gray-900">{program.slots}</div>
                    </div>
                  </div>

                  {activeTab === 'available' && (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2">Eligibility Criteria</h4>
                          <ul className="space-y-1">
                            {program.eligibility?.slice(0, 3).map((criteria, index) => (
                              <li key={index} className="flex items-start text-sm">
                                <CheckCircle className="text-green-600 mr-2 mt-0.5 flex-shrink-0" size={12} />
                                <span className="text-gray-600">{criteria}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2">Benefits</h4>
                          <ul className="space-y-1">
                            {program.benefits?.slice(0, 3).map((benefit, index) => (
                              <li key={index} className="flex items-start text-sm">
                                <Award className="text-blue-600 mr-2 mt-0.5 flex-shrink-0" size={12} />
                                <span className="text-gray-600">{benefit}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="flex justify-between items-center">
                        <div className="text-sm text-gray-600">
                          <Calendar size={16} className="inline mr-1" />
                          Application closes: {program.deadline}
                        </div>
                        <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
                          Apply Now
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Application Process</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Follow these simple steps to apply for NDDC scholarship programs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {applicationSteps.map((step, index) => (
              <div key={step.step} className="text-center">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <step.icon className="text-green-600" size={32} />
                </div>
                <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-3 text-sm font-bold">
                  {step.step}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600 text-sm">{step.description}</p>
                {index < applicationSteps.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-1/2 w-full h-0.5 bg-green-200 transform translate-x-1/2"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Required Documents */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Required Documents</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Ensure you have all required documents ready before starting your application
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {requiredDocuments.map((document, index) => (
              <div key={index} className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <CheckCircle className="text-green-600 mr-3" size={20} />
                  <span className="text-gray-900 font-medium">{document}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center">
              <Download className="mr-2" size={20} />
              Download Document Checklist
            </button>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Inspiring stories from NDDC scholarship beneficiaries who are making a difference
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-green-50 p-6 rounded-lg">
              <div className="text-center mb-4">
                <img
                  src="https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=200"
                  alt="Success Story"
                  className="w-20 h-20 rounded-full mx-auto mb-3 object-cover"
                />
                <h3 className="font-semibold text-gray-900">Dr. Amaka Okafor</h3>
                <p className="text-sm text-gray-600">Medical Doctor</p>
              </div>
              <p className="text-gray-700 text-sm italic">
                "The NDDC scholarship enabled me to pursue my medical degree. Today, I'm serving my community 
                as a doctor and giving back to the Niger Delta region."
              </p>
            </div>

            <div className="bg-blue-50 p-6 rounded-lg">
              <div className="text-center mb-4">
                <img
                  src="https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=200"
                  alt="Success Story"
                  className="w-20 h-20 rounded-full mx-auto mb-3 object-cover"
                />
                <h3 className="font-semibold text-gray-900">Engr. Chidi Okwu</h3>
                <p className="text-sm text-gray-600">Petroleum Engineer</p>
              </div>
              <p className="text-gray-700 text-sm italic">
                "Through the NDDC engineering scholarship, I was able to study petroleum engineering. 
                I now work with an international oil company and contribute to Nigeria's energy sector."
              </p>
            </div>

            <div className="bg-orange-50 p-6 rounded-lg">
              <div className="text-center mb-4">
                <img
                  src="https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=200"
                  alt="Success Story"
                  className="w-20 h-20 rounded-full mx-auto mb-3 object-cover"
                />
                <h3 className="font-semibold text-gray-900">Prof. Emeka Nwosu</h3>
                <p className="text-sm text-gray-600">University Professor</p>
              </div>
              <p className="text-gray-700 text-sm italic">
                "The postgraduate scholarship allowed me to earn my PhD. I'm now a professor 
                training the next generation of leaders in the Niger Delta."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Need Help with Your Application?</h2>
          <p className="text-green-100 mb-8 max-w-2xl mx-auto">
            Our scholarship team is available to assist you with questions about eligibility, 
            application process, and required documents.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Scholarship Office</h3>
              <p className="text-green-100">scholarships@nddcbpdivc.com.ng</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Helpline</h3>
              <p className="text-green-100">+2347013253195</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Office Hours</h3>
              <p className="text-green-100">Mon - Fri: 8:00 AM - 5:00 PM</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Scholarships;