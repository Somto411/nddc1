import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import OurMission from './pages/OurMission';
import OurBoard from './pages/OurBoard';
import Projects from './pages/Projects';
import News from './pages/News';
import SupplyProcedure from './pages/SupplyProcedure';
import SupplyRequirements from './pages/SupplyRequirements';
import ProjectDatabase from './pages/ProjectDatabase';
import TenderConfirmation from './pages/TenderConfirmation';
import Scholarships from './pages/Scholarships';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/our-mission" element={<OurMission />} />
            <Route path="/our-board" element={<OurBoard />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/news" element={<News />} />
            <Route path="/supply-procedure" element={<SupplyProcedure />} />
            <Route path="/supply-requirements" element={<SupplyRequirements />} />
            <Route path="/project-database" element={<ProjectDatabase />} />
            <Route path="/tender-confirmation" element={<TenderConfirmation />} />
            <Route path="/scholarships" element={<Scholarships />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;